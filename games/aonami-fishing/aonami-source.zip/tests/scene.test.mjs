import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createCoast } from '../src/coast.js';
import { buildFish, SPECIES } from '../src/fish.js';

const originalDocument=globalThis.document;
// The full procedural scene can be built without a GPU for structural checks.
globalThis.document={createElement(type){
  assert.equal(type,'canvas');
  return {width:1,height:1,getContext(){return {
    createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),
    putImageData(){},fillRect(){},strokeRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},arc(){},fill(){},bezierCurveTo(){},
    createLinearGradient(){return {addColorStop(){}};},
  };}};
}};

test('the realistic harbor constructs with valid geometry and lighthouse in view',()=>{
  const scene=new THREE.Scene(),coast=createCoast(THREE,scene);
  assert.ok(scene.children.some(o=>o.isSky),'daylight atmosphere is physically modeled');
  const camera=new THREE.PerspectiveCamera(58,844/390,.035,2200);
  camera.rotation.order='YXZ';camera.position.set(0,3.48,8);camera.rotation.set(-.055,-.12,0);
  camera.updateMatrixWorld();camera.updateProjectionMatrix();
  const lighthouse=new THREE.Vector3(34,15,-65).project(camera);
  assert.ok(lighthouse.x>-1&&lighthouse.x<1&&lighthouse.y>-1&&lighthouse.y<1,'red lighthouse is inside initial view');
  let objects=0,instances=0,triangles=0;
  scene.traverse(o=>{
    if(!o.isMesh)return;
    objects++;
    const position=o.geometry?.attributes.position;
    assert.ok(position&&position.count>0);
    for(const n of position.array)assert.ok(Number.isFinite(n),'mesh vertices are finite');
    const index=o.geometry.index;
    if(index)for(const n of index.array)assert.ok(n<position.count,'triangle index is in bounds');
    const count=o.isInstancedMesh?o.count:1;
    if(o.isInstancedMesh){instances+=count;for(const n of o.instanceMatrix.array)assert.ok(Number.isFinite(n),'instance matrices are finite');}
    triangles+=Math.floor((index?index.count:position.count)/3)*count;
  });
  assert.ok(objects>80&&instances>1000&&triangles>150000);
  for(const [x,z,t]of[[0,-20,0],[34,-65,9],[-40,-80,25]])assert.ok(Number.isFinite(coast.waterHeight(x,z,t)));
  coast.update(.016,5,camera);
  assert.ok(coast.water.material.vertexShader.includes('waves(p.xz)'));
  assert.ok(coast.water.material.uniforms.rippleNormals.value.isTexture,'ocean has detail normal texture');
  assert.ok(coast.group.children.filter(o=>o.isMesh&&o.material?.vertexColors&&o.geometry?.attributes?.position?.count>5000).length>=4,'distant mountain meshes have detailed slopes');
  for(const species of SPECIES){const fish=buildFish(THREE,species.id,.7);assert.ok(fish.children.length>2);}
  coast.dispose();
});

test.after(()=>{globalThis.document=originalDocument;});
