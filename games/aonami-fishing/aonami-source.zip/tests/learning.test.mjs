import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import { DEFAULT_VOCABULARY, LearningSession, parseVocabulary, shouldSpeakOnReel, readVocabularyTransfer } from '../src/learning.js';
import { FishingEngine } from '../src/fishing.js';

const fakeStorage = () => {
  const items = new Map();
  return {
    getItem: key => items.get(key) ?? null,
    setItem: (key, value) => items.set(key, value),
    removeItem: key => items.delete(key),
  };
};

test('GoLingo JSON preserves word translations and excludes incomplete rows', () => {
  const deck = parseVocabulary({primaryLanguage:'en',learningLanguage:'ja',words:[
    {id:'101',word:'水',translation:'water',sentence:'水を飲みます。',sentenceTranslation:'I drink water.'},
    {id:'102',word:'船',translation:'boat'},
    {id:'bad',word:'魚',sentence:'魚を見ます。',sentenceTranslation:'I see a fish.'},
  ]});
  assert.equal(deck.words.length, 2);
  assert.equal(deck.words[0].translation, 'water');
  assert.equal(deck.words[0].sentenceTranslation, 'I drink water.');
  assert.equal(deck.words[1].translation, 'boat');
  assert.equal(parseVocabulary('海|sea\n魚|fish').words.length, 2);
  assert.throws(()=>parseVocabulary('魚'),/No usable/);
  assert.equal(parseVocabulary({words:[{word:'海',translation:'sea',audioUrl:'https://example.com/umi.mp3'}]}).words[0].audioUrl,'https://example.com/umi.mp3');
  assert.equal(parseVocabulary({words:[{word:'cá',translation:'fish',audioURL:'https://example.com/ca.mp3'}]}).words[0].audioUrl,'https://example.com/ca.mp3');
});

test('the GoLingo gallery #data lesson overrides built-in words and supplies pronunciation audio',()=>{
  const custom={primaryLanguage:'en',learningLanguage:'vi',words:[
    {id:'101',word:'cá',translation:'fish',audioURL:'https://example.com/ca.mp3'},
    {id:'102',word:'biển',translation:'sea'}
  ]};
  const link=new URL('https://xcergolingo.github.io/games/aonami-fishing/');
  link.hash='data='+encodeURIComponent(JSON.stringify(custom)); // app.js launchGame
  const transfer=readVocabularyTransfer(link);
  assert.equal(transfer.source,'hash');
  assert.equal(transfer.key,'data');
  const fromGallery=parseVocabulary(transfer.payload);
  assert.equal(fromGallery.learningLanguage,'vi');
  assert.deepEqual(fromGallery.words.map(w=>w.word),['cá','biển']);
  assert.deepEqual(fromGallery.words.map(w=>w.translation),['fish','sea']);
  let playback='';
  const session=new LearningSession({storage:fakeStorage(),speech:null,random:()=>0,
    bundledClips:{},audioFactory:url=>{playback=url;return{play:()=>Promise.resolve(),pause(){}};}});
  session.setVocabulary(fromGallery);
  assert.equal(session.nextWord().word,'cá');
  assert.equal(session.speakCurrent(),true);
  assert.equal(playback,'https://example.com/ca.mp3');
  session.catchWord('aji');
  assert.equal(session.visibleBasket()[0].translation,'fish');
  session.stop();
});

test('legacy query, #golingoLesson, and absent lesson links are recognized correctly',()=>{
  const content=JSON.stringify({primaryLanguage:'en',learningLanguage:'ja',words:[{word:'水',translation:'water'}]});
  const fromQuery=new URL('https://example.com/game/?data='+encodeURIComponent(content));
  assert.equal(readVocabularyTransfer(fromQuery).payload,content);
  const fromHash=new URL('https://example.com/game/#golingoLesson='+encodeURIComponent(content));
  assert.equal(readVocabularyTransfer(fromHash).payload,content);
  fromHash.search='?data='+encodeURIComponent('{"words":[]}');
  assert.equal(readVocabularyTransfer(fromHash).source,'hash','gallery fragment takes priority');
  assert.equal(readVocabularyTransfer(new URL('https://example.com/game/')),null);
});

test('word is selected on a cast, collected on a catch and exported in GoLingo form', () => {
  const storage = fakeStorage();
  const session = new LearningSession({storage,random:()=>0,speech:null});
  assert.equal(session.vocabulary.words.length, DEFAULT_VOCABULARY.words.length);
  session.setVocabulary({primaryLanguage:'en',learningLanguage:'vi',words:[
    {id:'1',word:'cá',translation:'fish'}, {id:'2',word:'biển',translation:'sea'},
  ]});
  const first = session.nextWord();
  assert.equal(first.word, 'cá');
  session.catchWord('madai');
  assert.equal(session.visibleBasket().length, 1);
  const second = session.nextWord();
  assert.equal(second.word, 'biển', 'uncollected words take priority');
  session.catchWord('aji');
  const exported = session.exportBasket();
  assert.equal(exported.learningLanguage, 'vi');
  assert.deepEqual(exported.words.map(w=>w.translation), ['fish','sea']);
  const restored = new LearningSession({storage,random:()=>0,speech:null});
  assert.equal(restored.visibleBasket().length, 2);
  restored.clearBasket();
  assert.equal(restored.visibleBasket().length, 0);
});

test('tapping the hook speaks only the word in the learning language', () => {
  const previous = globalThis.SpeechSynthesisUtterance;
  class Utterance { constructor(text){this.text=text;} }
  globalThis.SpeechSynthesisUtterance = Utterance;
  try {
    const heard=[];
    const speech = {speak:u=>heard.push(u),cancel:()=>{},resume:()=>{},getVoices:()=>[]};
    const session = new LearningSession({storage:fakeStorage(),speech,random:()=>0});
    session.nextWord();
    assert.equal(session.speakCurrent(),true);
    assert.equal(heard.length,1);
    assert.equal(heard[0].text,'海');
    assert.equal(heard[0].lang,'ja-JP');
    assert.equal(heard[0].rate,.85);
    assert.equal(session._activeUtterance,heard[0],'keep utterance alive for WebKit');
    session.stop();
  } finally {globalThis.SpeechSynthesisUtterance=previous;}
});

test('tapping REEL plays a real embedded Japanese recording when device TTS is absent',()=>{
  const played=[],states=[];
  const audioFactory=url=>({
    src:url,loop:false,volume:0,paused:false,
    play(){played.push(this);this.onplaying?.();return Promise.resolve();},
    pause(){this.paused=true;},
  });
  const session=new LearningSession({storage:fakeStorage(),random:()=>0,speech:null,
    audioFactory,bundledClips:{'海':'data:audio/mpeg;base64,dummy'},onPlayback:event=>states.push(event)});
  session.nextWord();
  assert.equal(session.speakCurrent(),true);
  assert.equal(played.length,1);
  assert.equal(played[0].src,'data:audio/mpeg;base64,dummy');
  assert.equal(played[0].loop,true,'repeat word with quiet pause included in the clip');
  assert.equal(played[0].volume,1);
  assert.equal(states[0].source,'recorded');
  assert.equal(states[0].state,'playing');
  session.stop();
  assert.equal(played[0].paused,true);
  assert.equal(session._activeAudio,null);
});

test('Start fishing activates pronunciation without a separate Test Voice tap',async()=>{
  const source=await readFile(new URL('../src/main.js',import.meta.url),'utf8');
  const startBody=source.match(/function start\(\)\{([\s\S]*?)\n\}/)?.[1];
  assert.ok(startBody,'Start fishing handler must exist');
  assert.match(startBody,/testWordVoice\(\)/,'Start should call the same direct-gesture pronunciation path as Test Voice');
  const formerAudio=globalThis.Audio;
  let constructed=0;
  const played=[];
  globalThis.Audio=class{
    constructor(){constructed++;this.loop=false;this.volume=1;this.src='';}
    play(){played.push(this.src);this.onplaying?.();return Promise.resolve();}
    pause(){}
  };
  try{
    const session=new LearningSession({storage:fakeStorage(),speech:null,bundledClips:{}});
    session.setVocabulary({primaryLanguage:'en',learningLanguage:'vi',words:[
      {word:'cá',translation:'fish',audioURL:'https://example.com/fish.mp3'},
      {word:'biển',translation:'sea',audioURL:'https://example.com/sea.mp3'}
    ]});
    // Start fishing plays a sample from the imported deck inside the Start
    // gesture. A later REEL reuses that very same authorized audio element.
    assert.equal(session.speakWord(session.vocabulary.words[0]),true);
    assert.equal(session.speakWord(session.vocabulary.words[1]),true);
    assert.deepEqual(played,['https://example.com/fish.mp3','https://example.com/sea.mp3']);
    assert.equal(constructed,1,'WebKit playback permission must stay with one audio element');
    session.stop();
  }finally{globalThis.Audio=formerAudio;}
});

test('custom GoLingo audioUrl takes priority over the default clip',()=>{
  let urlPlayed='';
  const session=new LearningSession({storage:fakeStorage(),speech:null,random:()=>0,
    audioFactory:url=>{urlPlayed=url;return{play:()=>Promise.resolve(),pause(){}};},
    bundledClips:{'海':'data:audio/mpeg;base64,default'}});
  session.setVocabulary({learningLanguage:'ja',primaryLanguage:'en',words:[{word:'海',translation:'sea',audioUrl:'https://example.com/umi.mp3'}]});
  session.nextWord();
  assert.equal(session.speakCurrent(),true);
  assert.equal(urlPlayed,'https://example.com/umi.mp3');
  session.catchWord('madai');
  assert.equal(session.exportBasket().words[0].audioUrl,'https://example.com/umi.mp3');
  session.stop();
});

test('no recording and no speech engine reports unavailable rather than fake success',()=>{
  const session=new LearningSession({storage:fakeStorage(),random:()=>0,speech:null,audioFactory:()=>null,bundledClips:{}});
  session.nextWord();
  assert.equal(session.speakCurrent(),false);
});

test('a blocked media play falls back to a device voice',async()=>{
  const previous=globalThis.SpeechSynthesisUtterance;
  globalThis.SpeechSynthesisUtterance=class {constructor(text){this.text=text;}};
  try{
    const heard=[];
    const session=new LearningSession({storage:fakeStorage(),random:()=>0,
      speech:{speak:u=>heard.push(u),cancel:()=>{},resume:()=>{},getVoices:()=>[]},
      bundledClips:{'海':'data:audio/mpeg;base64,dummy'},
      audioFactory:()=>({play:()=>Promise.reject(new Error('blocked')),pause(){}})});
    session.nextWord();assert.equal(session.speakCurrent(),true);
    await Promise.resolve();
    assert.equal(heard.length,1);
    assert.equal(heard[0].text,'海');
    session.stop();
  }finally{globalThis.SpeechSynthesisUtterance=previous;}
});

test('reeling speech triggers in a fish fight without rapid duplicate restarts',()=>{
  assert.equal(shouldSpeakOnReel('waiting',3,-100),false);
  assert.equal(shouldSpeakOnReel('fighting',4,-100),true);
  assert.equal(shouldSpeakOnReel('fighting',4.2,4),false);
  assert.equal(shouldSpeakOnReel('fighting',4.75,4),true);
});

for(const mode of ['lure','float']) test(`${mode}: cast, hook bite, reel, collect vocabulary`, () => {
  const events=[];
  const learning=new LearningSession({storage:fakeStorage(),random:()=>0,speech:null});
  const engine=new FishingEngine({random:()=>.4,onEvent:e=>{
    events.push(e.type);
    if(e.type==='cast')learning.nextWord();
    if(e.type==='catch')learning.catchWord(e.speciesId);
  }});
  engine.setMode(mode);
  assert.equal(engine.cast({power:.7,direction:{x:.1,y:0,z:-1}}),true);
  let seconds=0;
  while(engine.state==='casting'||engine.state==='waiting'){
    engine.update(.05,seconds);seconds+=.05;
    if(seconds>35)throw Error('No bite');
  }
  assert.equal(engine.state,'bite');
  assert.equal(engine.hook(),true);
  let reeling=true;
  while(engine.state==='fighting'){
    if(engine.tension>.88)reeling=false;
    else if(engine.tension<.71)reeling=true;
    engine.setReeling(reeling);engine.update(.05,seconds);seconds+=.05;
    if(seconds>240)throw Error('The fish never reached the pier');
  }
  assert.equal(engine.state,'caught');
  assert.deepEqual(events.filter(x=>['cast','splash','bite','hook','catch'].includes(x)),['cast','splash','bite','hook','catch']);
  assert.equal(learning.visibleBasket().length,1);
});
