// A tapered, animated graphite rod, cork grip, spinning reel and line guides.
export function createRod(THREE) {
  const group = new THREE.Group();
  const carbon = new THREE.MeshStandardMaterial({color:0x172e32,metalness:.55,roughness:.3});
  const trim = new THREE.MeshStandardMaterial({color:0xa7b7b4,metalness:.86,roughness:.24});
  const dark = new THREE.MeshStandardMaterial({color:0x233d3b,metalness:.6,roughness:.34});
  const corkCanvas=document.createElement('canvas');corkCanvas.width=128;corkCanvas.height=128;
  const ctx=corkCanvas.getContext('2d');ctx.fillStyle='#ab8960';ctx.fillRect(0,0,128,128);
  for(let i=0;i<1800;i++){ctx.fillStyle=i%3?'rgba(58,39,20,.18)':'rgba(235,204,151,.25)';ctx.fillRect(Math.random()*128,Math.random()*128,Math.random()*5+1,Math.random()*1.8+.5);}
  const corkTex=new THREE.CanvasTexture(corkCanvas);corkTex.colorSpace=THREE.SRGBColorSpace;corkTex.wrapS=corkTex.wrapT=THREE.RepeatWrapping;corkTex.repeat.set(1,4);
  const cork=new THREE.MeshStandardMaterial({map:corkTex,roughness:.95});
  const axis=new THREE.Vector3(0,.32,-1).normalize(),up=new THREE.Vector3(0,1,0);
  function cyl(r1,r2,len,mat,pos,dir=axis){const m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,len,12),mat);m.position.copy(pos);m.quaternion.setFromUnitVectors(up,dir);group.add(m);return m;}
  cyl(.039,.045,.5,cork,new THREE.Vector3(0,-.06,.19));
  cyl(.044,.044,.075,dark,new THREE.Vector3(0,-.15,.45));
  cyl(.042,.042,.05,trim,new THREE.Vector3(0,.025,-.07));
  cyl(.027,.028,.32,dark,new THREE.Vector3(0,.06,-.2));
  // Curved reel foot and spool below the grip.
  cyl(.016,.016,.15,trim,new THREE.Vector3(0,-.09,-.12),new THREE.Vector3(0,1,0));
  const reel=new THREE.Mesh(new THREE.SphereGeometry(.1,16,12),dark);reel.scale.set(.58,.9,1.15);reel.position.set(0,-.2,-.14);group.add(reel);
  const spool=cyl(.065,.065,.10,trim,new THREE.Vector3(0,-.22,-.27),new THREE.Vector3(0,0,1));
  const lineSpool=cyl(.054,.054,.055,new THREE.MeshStandardMaterial({color:0xc8d4ac,roughness:.7}),new THREE.Vector3(0,-.22,-.295),new THREE.Vector3(0,0,1));
  const bail=new THREE.Mesh(new THREE.TorusGeometry(.085,.005,5,24,Math.PI*1.55),trim);bail.position.set(0,-.22,-.3);group.add(bail);
  const crank=new THREE.Group();crank.position.set(-.055,-.19,-.12);group.add(crank);
  const arm=new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.14,6),trim);arm.rotation.z=.8;arm.position.set(-.05,-.04,0);crank.add(arm);
  const knob=new THREE.Mesh(new THREE.CapsuleGeometry(.02,.04,3,6),dark);knob.rotation.z=Math.PI/2;knob.position.set(-.10,-.09,0);crank.add(knob);
  // Rounded glove and a muted canvas cuff are kept low in the frame.
  const handMat=new THREE.MeshStandardMaterial({color:0x9e8d70,roughness:.94});
  const palm=new THREE.Mesh(new THREE.SphereGeometry(.075,14,10),handMat);palm.scale.set(.78,1.05,1.65);palm.position.set(.025,-.07,.14);group.add(palm);
  for(let k=0;k<4;k++){const finger=new THREE.Mesh(new THREE.CapsuleGeometry(.022,.055,3,7),handMat);finger.rotation.z=-.7;finger.position.set(-.015,-.05-k*.014,.065+k*.046);group.add(finger);}
  const cuff=new THREE.Mesh(new THREE.CylinderGeometry(.075,.10,.3,14),new THREE.MeshStandardMaterial({color:0x284e4f,roughness:1}));cuff.quaternion.setFromUnitVectors(up,new THREE.Vector3(.12,-.27,.85).normalize());cuff.position.set(.04,-.15,.36);group.add(cuff);
  const N=25,segments=[],guides=[],a=new THREE.Vector3(),b=new THREE.Vector3(),v=new THREE.Vector3();
  for(let i=0;i<N;i++){const r=.019*(1-i/N)+.0025;const m=new THREE.Mesh(new THREE.CylinderGeometry(r*.96,r,1,8),carbon);group.add(m);segments.push(m);}
  for(let i=0;i<7;i++){const m=new THREE.Mesh(new THREE.TorusGeometry(.026-i*.0025,.003,4,10),trim);group.add(m);guides.push(m);}
  function point(out,s,bend,time,struggle){return out.set(Math.sin(s*2.4)*bend*.1+Math.sin(time*16)*struggle*s*s*.018,.13+.77*s-bend*.58*s*s,-.38-2.48*s+bend*.28*s*s);}
  const tipLocal=new THREE.Vector3(),tip=new THREE.Vector3();
  function update(dt,time,{bend=0,reeling=false,struggle=0}={}){
    for(let i=0;i<N;i++){point(a,i/N,bend,time,struggle);point(b,(i+1)/N,bend,time,struggle);v.subVectors(b,a);segments[i].position.copy(a).add(b).multiplyScalar(.5);segments[i].scale.y=v.length();segments[i].quaternion.setFromUnitVectors(up,v.normalize());}
    guides.forEach((g,i)=>{const s=.10+i*.15;point(g.position,s,bend,time,struggle);g.position.y-=.022;g.rotation.x=.16-bend*s*.3;});
    point(tipLocal,1,bend,time,struggle);
    if(reeling)crank.rotation.x-=dt*13;
    bail.rotation.z+=reeling?dt*14:0;
  }
  function getTip(){group.updateWorldMatrix(true,false);return tip.copy(tipLocal).applyMatrix4(group.matrixWorld);}
  update(0,0);
  return {group,update,getTip};
}
