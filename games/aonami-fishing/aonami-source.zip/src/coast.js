// Aonami coast — procedural assets, animated water and planar reflections.
// No remote textures or model assets are required.
import { Sky } from 'three/addons/objects/Sky.js';
export function createCoast(THREE, scene, opts = {}) {
  const renderer = opts.renderer;
  const pierY = 1.65;
  const group = new THREE.Group();
  group.name = 'Aonami coast';
  scene.add(group);
  scene.background = new THREE.Color('#8fcbdf');
  scene.fog = new THREE.FogExp2('#b4dbe2', 0.0017);
  // A small prefiltered sky-and-sea environment gives metal, wet fish skin and
  // glazing plausible reflections without live environment captures each frame.
  let environmentTarget=null;
  if(renderer){
    try{
      const eCanvas=document.createElement('canvas');eCanvas.width=512;eCanvas.height=256;
      const ectx=eCanvas.getContext('2d'),image=ectx.createImageData(512,256);
      for(let y=0;y<256;y++)for(let x=0;x<512;x++){
        const u=x/512,v=y/256,i=(y*512+x)*4;
        let r,g,b;
        if(v<.5){
          const t=v*2;
          r=47+145*Math.pow(t,.7);g=126+91*Math.pow(t,.7);b=189+32*Math.pow(t,.7);
          const cloud=Math.sin(u*43+Math.sin(u*21)*2)*Math.cos(v*37+u*8)+Math.sin(u*88-v*51)*.26;
          const whitening=Math.max(0,Math.min(1,(cloud-.56)*2.5))*(1-Math.abs(t-.66)*.4);
          r+=(247-r)*whitening;g+=(247-g)*whitening;b+=(239-b)*whitening;
          let du=Math.abs(u-.30);du=Math.min(du,1-du);
          const sun=Math.exp(-du*du*6500-(v-.18)*(v-.18)*8200);
          r+=(255-r)*sun;g+=(250-g)*sun;b+=(219-b)*sun;
        }else{
          const t=(v-.5)*2;
          r=72-61*t;g=161-79*t;b=168-59*t;
        }
        image.data[i]=r;image.data[i+1]=g;image.data[i+2]=b;image.data[i+3]=255;
      }
      ectx.putImageData(image,0,0);
      const environment=new THREE.CanvasTexture(eCanvas);
      environment.colorSpace=THREE.SRGBColorSpace;
      environment.mapping=THREE.EquirectangularReflectionMapping;
      const pmrem=new THREE.PMREMGenerator(renderer);
      environmentTarget=pmrem.fromEquirectangular(environment);
      scene.environment=environmentTarget.texture;
      scene.environmentIntensity=.72;
      pmrem.dispose();environment.dispose();
    }catch(error){console.warn('Environment reflections unavailable',error);}
  }
  const sunDirection = new THREE.Vector3(-0.38, 0.79, -0.20).normalize();
  const hemi = new THREE.HemisphereLight('#c4e7ff', '#6d8262', 1.6);
  const sun = new THREE.DirectionalLight('#fff3d6', 2.9);
  sun.position.copy(sunDirection).multiplyScalar(110);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -50; sun.shadow.camera.right = 50;
  sun.shadow.camera.top = 45; sun.shadow.camera.bottom = -45;
  sun.shadow.camera.near = 1; sun.shadow.camera.far = 240;
  sun.shadow.bias = -0.0007; sun.shadow.normalBias = 0.09;
  sun.target.position.set(10, 0, -15);
  group.add(hemi, sun, sun.target);

  let seed = 2841;
  const rand = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  const mat = (color, extra = {}) => new THREE.MeshStandardMaterial({color, roughness: 0.85, ...extra});
  // Tangent-space normals made from a repeatable surface height field. The
  // variation affects actual reflected light, rather than only darkening paint.
  function surfaceMaps(kind, width, height) {
    const diffuseCanvas=document.createElement('canvas'),normalCanvas=document.createElement('canvas');
    diffuseCanvas.width=normalCanvas.width=width;diffuseCanvas.height=normalCanvas.height=height;
    const dc=diffuseCanvas.getContext('2d'),nc=normalCanvas.getContext('2d');
    const color=dc.createImageData(width,height),normals=nc.createImageData(width,height);
    const bump=new Float32Array(width*height);
    const hash=(x,y)=>{let n=Math.imul(x+173,374761393)^Math.imul(y+479,668265263);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;};
    const knots=[[.34,.29],[.77,.72],[.19,.91]];
    for(let y=0;y<height;y++)for(let x=0;x<width;x++){
      const i=y*width+x,j=i*4,random=hash(x,y)-.5;
      let h,r,g,b;
      if(kind==='wood'){
        let warp=5*Math.sin(y*.025)+3*Math.sin(y*.009+x*.03);
        let knot=0;
        for(const [ku,kv] of knots){
          const dx=(x/width-ku)*width/11,dy=(y/height-kv)*height/33;
          const d=Math.hypot(dx,dy);
          const halo=Math.exp(-d*d*.18);
          warp+=Math.sin(d*5)*halo*9;
          knot+=halo*(.8-.5*Math.sin(d*9));
        }
        const stripe=Math.sin((x+warp)*.29)*.19+Math.sin((x+warp)*.91+y*.009)*.065;
        h=.48+stripe+random*.11-knot*.23;
        const shade=h*46-19;
        r=153+shade;g=124+shade*.91;b=88+shade*.75;
      }else{
        const large=Math.sin(x*.076+y*.031)*Math.cos(y*.093-x*.027);
        const small=Math.sin(x*.31+y*.27)*Math.sin(y*.24-x*.17);
        const hairline=Math.pow(Math.max(0,Math.sin(x*.117+y*.035)),28)*.26;
        h=.49+large*.16+small*.105+random*.2-hairline;
        const shade=h*42-18;
        const moss=Math.max(0,Math.sin(x*.037+y*.016)*Math.cos(y*.043))*.18;
        r=144+shade-moss*35;g=145+shade-moss*17;b=137+shade-moss*36;
      }
      bump[i]=h;
      color.data[j]=clampByte(r);color.data[j+1]=clampByte(g);color.data[j+2]=clampByte(b);color.data[j+3]=255;
    }
    const strength=kind==='wood'?1.7:2.7;
    for(let y=0;y<height;y++)for(let x=0;x<width;x++){
      const i=y*width+x,j=i*4;
      const left=bump[y*width+(x-1+width)%width],right=bump[y*width+(x+1)%width];
      const up=bump[((y-1+height)%height)*width+x],down=bump[((y+1)%height)*width+x];
      let nx=(left-right)*strength,ny=(up-down)*strength,nz=1;
      const inv=1/Math.hypot(nx,ny,nz);nx*=inv;ny*=inv;nz*=inv;
      normals.data[j]=Math.round((nx*.5+.5)*255);normals.data[j+1]=Math.round((ny*.5+.5)*255);normals.data[j+2]=Math.round((nz*.5+.5)*255);normals.data[j+3]=255;
    }
    dc.putImageData(color,0,0);nc.putImageData(normals,0,0);
    const diffuse=new THREE.CanvasTexture(diffuseCanvas),normal=new THREE.CanvasTexture(normalCanvas);
    diffuse.colorSpace=THREE.SRGBColorSpace;
    for(const tex of [diffuse,normal]){tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.anisotropy=renderer?Math.min(8,renderer.capabilities.getMaxAnisotropy()):4;}
    return {map:diffuse,normalMap:normal};
  }
  // Seamless small wave normals: the large ocean geometry defines the swell,
  // while two flowing texture scales produce the changing capillary facets
  // that break sunlight into natural highlights on real seawater.
  function makeSeaNormalTexture(){
    const size=256,canvas=document.createElement('canvas');canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d'),image=ctx.createImageData(size,size);
    const h=new Float32Array(size*size),tau=Math.PI*2;
    for(let y=0;y<size;y++)for(let x=0;x<size;x++){
      const a=tau*(x*9+y*3)/size,b=tau*(-x*5+y*11)/size,c=tau*(x*19-y*13)/size;
      h[y*size+x]=Math.sin(a)*.52+Math.sin(b)*.30+Math.sin(c)*.10+
        Math.sin(a*2+b)*.08;
    }
    for(let y=0;y<size;y++)for(let x=0;x<size;x++){
      const left=h[y*size+(x+size-1)%size],right=h[y*size+(x+1)%size];
      const up=h[((y+size-1)%size)*size+x],down=h[((y+1)%size)*size+x];
      const nx=(left-right)*1.7,ny=(up-down)*1.7,nz=1,inv=1/Math.hypot(nx,ny,nz);
      const i=(y*size+x)*4;
      image.data[i]=Math.round((nx*inv*.5+.5)*255);
      image.data[i+1]=Math.round((ny*inv*.5+.5)*255);
      image.data[i+2]=Math.round((nz*inv*.5+.5)*255);
      image.data[i+3]=255;
    }
    ctx.putImageData(image,0,0);
    const texture=new THREE.CanvasTexture(canvas);
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;
    texture.magFilter=THREE.LinearFilter;
    texture.anisotropy=renderer?Math.min(8,renderer.capabilities.getMaxAnisotropy()):4;
    return texture;
  }
  const clampByte=n=>Math.max(0,Math.min(255,Math.round(n)));
  const addMesh = (geo, material, x, y, z, owner = group) => {
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(x, y, z); mesh.castShadow = true; mesh.receiveShadow = true;
    owner.add(mesh); return mesh;
  };
  const cylinder = (rt, rb, h, material, x, y, z, owner = group, sides = 32) =>
    addMesh(new THREE.CylinderGeometry(rt, rb, h, sides), material, x, y, z, owner);
  const beam = (a, b, radius, material, owner = group, sides = 10) => {
    const delta = new THREE.Vector3().subVectors(b, a);
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, delta.length(), sides), material);
    mesh.position.copy(a).add(b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
    mesh.castShadow = true; mesh.receiveShadow = true; owner.add(mesh); return mesh;
  };

  const woodMaps=surfaceMaps('wood',256,512);
  const timber = new THREE.MeshStandardMaterial({color:'#faf1df',...woodMaps,normalScale:new THREE.Vector2(.36,.36),roughness:0.88});
  const timberDark = new THREE.MeshStandardMaterial({color:'#bcb0a0',...woodMaps,normalScale:new THREE.Vector2(.4,.4),roughness:0.94});
  const nailMat = mat('#393b37', {metalness:0.65,roughness:0.52});
  // Planks run away from the player, with real gaps and end caps.
  const plankGeometry = new THREE.BoxGeometry(0.485, 0.23, 4.26);
  const planks = new THREE.InstancedMesh(plankGeometry, timber, 18 * 3);
  const dummy = new THREE.Object3D(); let index = 0;
  for (let row = 0; row < 3; row++) for (let col = 0; col < 18; col++) {
    dummy.position.set(-4.25 + col * 0.5, pierY - 0.115 + rand() * 0.012, 7.15 + row * 4.3);
    dummy.rotation.set(0, 0, 0); dummy.scale.set(1,1,1); dummy.updateMatrix(); planks.setMatrixAt(index, dummy.matrix);
    planks.setColorAt(index++, new THREE.Color().setHSL(0.105, 0.10 + rand() * 0.10, 0.68 + rand() * 0.25));
  }
  planks.castShadow = true; planks.receiveShadow = true; group.add(planks);
  const nails = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.026,0.026,0.009,8),nailMat,108);
  index = 0;
  for(let row=0;row<3;row++) for(let col=0;col<18;col++) for(const dz of [-1.9,1.9]) {
    dummy.position.set(-4.25+col*0.5,pierY+0.014,7.15+row*4.3+dz);dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);dummy.updateMatrix();nails.setMatrixAt(index++,dummy.matrix);
  }
  group.add(nails);
  addMesh(new THREE.BoxGeometry(9.3,0.48,0.40),timberDark,0,pierY-0.32,4.93);
  for(const x of [-4.45,4.45]) {
    addMesh(new THREE.BoxGeometry(0.36,0.55,13.3),timberDark,x,pierY-0.42,11.4);
    for(const z of [5.5,11.5,17.1]) {
      const post = cylinder(0.24,0.29,4.9,timberDark,x,-0.15,z,group,12);
      post.rotation.z = (rand()-0.5)*0.025;
      cylinder(0.285,0.29,0.12,timber,x,2.34,z,group,14);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.26,0.025,6,18),nailMat);ring.rotation.x=Math.PI/2;ring.position.set(x,1.9,z);group.add(ring);
    }
    // A low side rope leaves the entire fishing edge open.
    const ropeMat = mat('#b1a98c');
    for(let span=0;span<2;span++) {
      const points=[];for(let k=0;k<=16;k++){const s=k/16;points.push(new THREE.Vector3(x,2.07-0.24*Math.sin(s*Math.PI),5.5+span*5.8+s*5.8));}
      addMesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),24,0.032,5,false),ropeMat,0,0,0);
    }
  }
  // Dock cleats and a gently coiled rope, kept away from the casting view.
  for(const x of [-3.6,3.6]) {
    addMesh(new THREE.BoxGeometry(0.44,0.08,0.18),nailMat,x,pierY+0.04,6.1);
    addMesh(new THREE.BoxGeometry(0.12,0.15,0.10),nailMat,x,pierY+0.14,6.1);
    const cross=addMesh(new THREE.CapsuleGeometry(0.05,0.55,4,8),nailMat,x,pierY+0.23,6.1);cross.rotation.z=Math.PI/2;
  }
  const ropeCurve=[];for(let i=0;i<=180;i++){const t=i/180,a=t*Math.PI*10,r=0.19+t*0.38;ropeCurve.push(new THREE.Vector3(-3.3+Math.cos(a)*r,pierY+0.045,8+Math.sin(a)*r));}
  addMesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(ropeCurve),180,0.034,5,false),mat('#b9a882'),0,0,0);

  // A few working-pier objects give the foreground a lived-in scale without
  // getting between the player and the open water or the lighthouse.
  const boxMetal=mat('#526e72',{metalness:.24,roughness:.43});
  const cooler=addMesh(new THREE.BoxGeometry(.86,.47,.52),mat('#e3e6db',{roughness:.64}),-3.05,pierY+.24,6.9);
  cooler.rotation.y=-.08;
  const lid=addMesh(new THREE.BoxGeometry(.92,.11,.57),boxMetal,-3.05,pierY+.53,6.9);lid.rotation.y=-.08;
  const coolerHandle=addMesh(new THREE.TorusGeometry(.17,.019,6,17,Math.PI),mat('#647c78',{metalness:.55}),-3.05,pierY+.58,6.56);
  coolerHandle.rotation.z=Math.PI;
  const tackle=addMesh(new THREE.BoxGeometry(.47,.22,.32),mat('#5a7360',{metalness:.10,roughness:.74}),-2.15,pierY+.13,6.74);
  addMesh(new THREE.BoxGeometry(.47,.025,.32),mat('#354c43',{roughness:.42}),-2.15,pierY+.25,6.74);
  addMesh(new THREE.BoxGeometry(.10,.045,.028),mat('#d3b87e',{metalness:.67,roughness:.35}),-2.15,pierY+.21,6.55);
  const lifering=new THREE.Group();lifering.position.set(4.37,2.11,7.1);lifering.rotation.y=Math.PI/2;group.add(lifering);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.31,.075,10,36),mat('#ce5d44',{roughness:.66}));lifering.add(ring);
  for(let i=0;i<4;i++){
    const patch=new THREE.Mesh(new THREE.TorusGeometry(.31,.078,6,8,Math.PI/5),mat('#eceadf',{roughness:.67}));
    patch.rotation.z=i*Math.PI/2+.08;lifering.add(patch);
  }
  const strap=addMesh(new THREE.BoxGeometry(.09,.54,.11),mat('#818477',{roughness:.91}),4.39,2.09,7.1);strap.rotation.x=.1;
  // Dark tidal staining and pale barnacles on the sea-level pier pilings.
  const wetTimber=mat('#535f54',{roughness:.99});
  const barnacleMat=mat('#a8b5a9',{roughness:.97});
  const barnacleGeo=new THREE.IcosahedronGeometry(1,0);
  const barnacles=new THREE.InstancedMesh(barnacleGeo,barnacleMat,180);
  let barnacleCount=0;
  for(const x of [-4.45,4.45])for(const z of [5.5,11.5,17.1]){
    cylinder(.291,.296,.77,wetTimber,x,.03,z,group,12);
    for(let j=0;j<30;j++){
      const a=rand()*Math.PI*2,h=-.21+rand()*.58,r=.29;
      const rr=.019+rand()*.033;
      dummy.position.set(x+Math.cos(a)*r,h,z+Math.sin(a)*r);
      dummy.scale.set(rr,rr*(.6+rand()),rr);dummy.rotation.set(rand(),rand()*6.28,rand());dummy.updateMatrix();barnacles.setMatrixAt(barnacleCount++,dummy.matrix);
    }
  }
  barnacles.count=barnacleCount;barnacles.receiveShadow=false;group.add(barnacles);
  const pilePositions=[];
  for(const x of [-4.45,4.45])for(const z of [5.5,11.5,17.1])pilePositions.push([x,z]);
  const pileWakes=new THREE.InstancedMesh(new THREE.RingGeometry(.30,.43,28),new THREE.MeshBasicMaterial({color:'#dbeeea',transparent:true,opacity:.16,depthWrite:false,side:THREE.DoubleSide}),pilePositions.length);
  pileWakes.frustumCulled=false;pileWakes.renderOrder=3;group.add(pileWakes);

  // Multi-scale coherent height noise gives the islands real ridgelines and
  // eroded shoulders; the prior repeating sinusoidal mounds looked artificial.
  const lerp=(a,b,t)=>a+(b-a)*t;
  const smooth=t=>t*t*(3-2*t);
  const hash2=(x,y)=>{
    let n=Math.imul(x,374761393)+Math.imul(y,668265263)+1376312589;
    n=Math.imul(n^(n>>>13),1274126177);
    return ((n^(n>>>16))>>>0)/4294967295;
  };
  const valueNoise=(x,z)=>{
    const ix=Math.floor(x),iz=Math.floor(z),fx=smooth(x-ix),fz=smooth(z-iz);
    return lerp(lerp(hash2(ix,iz),hash2(ix+1,iz),fx),lerp(hash2(ix,iz+1),hash2(ix+1,iz+1),fx),fz)*2-1;
  };
  const noise=(x,z)=>valueNoise(x,z)*.58+valueNoise(x*2.02+8.7,z*2.02-2.6)*.28+valueNoise(x*4.04-5.1,z*4.04+7.9)*.14;
  function terrainHeight(u,v,height,phase){
    const wobble=.045*noise(u*5.4+phase,v*5.4);
    const edge=Math.max(0,1-u*u*.93-v*v*.97+wobble);
    const coastFall=Math.pow(edge,1.12);
    const spine=-.13+.19*Math.sin(u*2.5+phase*.6)+.16*noise(u*4.6+phase,2.4);
    const across=Math.abs(v-spine);
    const mountainRidge=Math.exp(-Math.pow(across*2.25,1.42));
    const ridgeNoise=1-Math.abs(noise(u*11+phase,v*9.8)*1.62);
    const sideGullies=noise(u*7.8+phase,v*6.4)*.13;
    const elevation=.48+.45*mountainRidge+.17*ridgeNoise+sideGullies;
    const escarpment=.93+.16*noise(u*21+phase,v*18);
    return coastFall*height*elevation*escarpment-1.15;
  }
  function makeIsland(cx,cz,wx,wz,height,phase) {
    const nx=130,nz=76,positions=[],colors=[],indices=[];
    for(let iz=0;iz<=nz;iz++) for(let ix=0;ix<=nx;ix++) {
      const u=ix/nx*2-1,v=iz/nz*2-1;
      const y=terrainHeight(u,v,height,phase);
      positions.push(cx+u*wx,y,cz+v*wz);
      const c=new THREE.Color();
      if(y<.8)c.set('#9da69a');
      else if(y<3)c.set('#768675');
      else if(y/height>.69&&noise(u*8,v*13)>.17)c.set('#7b847b');
      else c.setHSL(.28+noise(u*9,v*11)*.035,.28+noise(u*12,v*8)*.055,.19+noise(u*12,v*11)*.055+y/height*.055);
      colors.push(c.r,c.g,c.b);
    }
    for(let iz=0;iz<nz;iz++)for(let ix=0;ix<nx;ix++){const a=iz*(nx+1)+ix,b=a+1,c=a+nx+1,d=c+1;indices.push(a,c,b,b,c,d);}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.setIndex(indices);geo.computeVertexNormals();
    const normals=geo.attributes.normal,colorAttr=geo.attributes.color,rockColor=new THREE.Color('#8a8f85');
    for(let i=0;i<normals.count;i++){
      // The steep faces expose bare rock and thin, faded alpine vegetation.
      const y=geo.attributes.position.getY(i);
      const steep=Math.max(0,Math.min(1,(1-normals.getY(i)-.20)*1.35));
      const high=Math.max(0,Math.min(1,(y/height-.53)*1.45));
      const stoneAmount=Math.min(.82,steep*(.55+high*.45)+high*.10);
      colorAttr.setXYZ(i,
        lerp(colorAttr.getX(i),rockColor.r,stoneAmount),
        lerp(colorAttr.getY(i),rockColor.g,stoneAmount),
        lerp(colorAttr.getZ(i),rockColor.b,stoneAmount));
    }
    const island=addMesh(geo,new THREE.MeshStandardMaterial({vertexColors:true,roughness:1}),0,0,0);island.castShadow=false;
    return {island,cx,cz,wx,wz,height,phase};
  }
  const islandData=[
    makeIsland(-135,-235,126,65,77,.2),
    makeIsland(-40,-420,170,80,91,1.7),
    makeIsland(178,-290,163,85,92,3.8),
    makeIsland(330,-430,200,93,93,5.1)
  ];
  // Densely grouped tree crowns give the ridgelines an irregular, natural edge.
  const forest=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1,1),mat('#6a8562'),820);
  let trees=0;
  for(const island of islandData){
    const attempts=island.cz>-350?300:200;
    for(let i=0;i<attempts;i++){
      const u=(rand()*2-1)*.87,v=(rand()*2-1)*.87;
      if(u*u+v*v>.74)continue;
      const ground=terrainHeight(u,v,island.height,island.phase);
      if(ground<5)continue;
      const radius=1.15+rand()*2.0,high=1.45+rand()*2.3;
      dummy.position.set(island.cx+u*island.wx,ground+high*.52,island.cz+v*island.wz);
      dummy.rotation.set(rand()*.14,rand()*6.28,rand()*.16);
      dummy.scale.set(radius,high,radius*(.9+rand()*.3));dummy.updateMatrix();
      forest.setMatrixAt(trees,dummy.matrix);
      forest.setColorAt(trees,new THREE.Color().setHSL(.255+rand()*.045,.22+rand()*.1,.24+rand()*.1));
      trees++;
    }
  }
  forest.count=trees;forest.castShadow=false;forest.receiveShadow=true;group.add(forest);

  // Long interlocking stone breakwater. Individual blocks catch the side light.
  const stoneMaps=surfaceMaps('stone',256,256);
  const stone=mat('#efede5',{...stoneMaps,normalScale:new THREE.Vector2(.55,.55)});
  const stoneTop=mat('#f7f4ed',{...stoneMaps,normalScale:new THREE.Vector2(.55,.55)});
  const breakStart=new THREE.Vector3(91,0,-17),breakEnd=new THREE.Vector3(31,0,-70);
  const breakVec=new THREE.Vector3().subVectors(breakEnd,breakStart);const breakLen=breakVec.length(),breakDir=breakVec.clone().normalize();
  const side=new THREE.Vector3(-breakDir.z,0,breakDir.x);const angle=Math.atan2(breakDir.x,breakDir.z);
  const wall=addMesh(new THREE.BoxGeometry(6.0,2.4,breakLen+4),stone, (breakStart.x+breakEnd.x)/2,0.3,(breakStart.z+breakEnd.z)/2);wall.rotation.y=angle;
  const cap=addMesh(new THREE.BoxGeometry(6.6,0.38,breakLen+5),stoneTop,(breakStart.x+breakEnd.x)/2,1.69,(breakStart.z+breakEnd.z)/2);cap.rotation.y=angle;
  const count=Math.ceil(breakLen/2.15);
  const blocks=new THREE.InstancedMesh(new THREE.BoxGeometry(0.38,0.62,2.03),stone,count*6);index=0;
  for(const s of [-1,1])for(let row=0;row<3;row++)for(let i=0;i<count;i++){
    const along=(i+(row%2)*0.45)*2.12;
    dummy.position.copy(breakStart).addScaledVector(breakDir,Math.min(along,breakLen)).addScaledVector(side,s*3.08);
    dummy.position.y=-0.05+row*0.65;dummy.rotation.set(0,angle,0);dummy.scale.set(1,1,1);dummy.updateMatrix();blocks.setMatrixAt(index,dummy.matrix);
    blocks.setColorAt(index++,new THREE.Color().setHSL(0.12,0.04+rand()*0.07,0.65+rand()*0.3));
  }
  blocks.castShadow=true;blocks.receiveShadow=true;group.add(blocks);
  const rockGeo=new THREE.IcosahedronGeometry(1,2);const rp=rockGeo.attributes.position;
  for(let i=0;i<rp.count;i++){
    const x=rp.getX(i),y=rp.getY(i),z=rp.getZ(i);
    const m=.89+.09*Math.sin(x*8.7+y*4.1)+.07*Math.sin(z*11.3-x*3.2)+rand()*.07;
    rp.setXYZ(i,x*m,y*m,z*m);
  }
  rockGeo.computeVertexNormals();
  const rocks=new THREE.InstancedMesh(rockGeo,mat('#c5c6be',{...stoneMaps,normalScale:new THREE.Vector2(.65,.65)}),156);
  for(let i=0;i<156;i++){
    const along=rand()*breakLen,s=i%2?1:-1;
    dummy.position.copy(breakStart).addScaledVector(breakDir,along).addScaledVector(side,s*(3.6+rand()*2.2));dummy.position.y=-0.25+rand()*0.4;
    dummy.rotation.set(rand()*3,rand()*6,rand()*3);dummy.scale.set(0.75+rand()*1.8,0.7+rand()*1.0,0.8+rand()*1.9);dummy.updateMatrix();rocks.setMatrixAt(i,dummy.matrix);
    rocks.setColorAt(i,new THREE.Color().setHSL(0.13,0.04,0.55+rand()*0.35));
  }rocks.castShadow=true;rocks.receiveShadow=true;group.add(rocks);
  // A damp, algae-stained tide band grounds the breakwater in the sea. The
  // thin foam fragments overlap the moving surface, instead of forming a
  // perfectly straight white stripe on each side.
  const tideMat=mat('#5d7166',{...stoneMaps,normalScale:new THREE.Vector2(.34,.34),roughness:.95});
  for(const sign of [-1,1]){
    const p=breakStart.clone().addScaledVector(breakDir,breakLen*.5).addScaledVector(side,sign*3.09);
    const wet=addMesh(new THREE.BoxGeometry(.16,.82,breakLen+1.2),tideMat,p.x,-.08,p.z);wet.rotation.y=angle;wet.castShadow=false;
  }
  const foamFragments=new THREE.InstancedMesh(new THREE.RingGeometry(.52,.74,14,1,.16,Math.PI*1.35),new THREE.MeshBasicMaterial({color:'#e2eee8',transparent:true,opacity:.27,depthWrite:false,side:THREE.DoubleSide}),95);
  for(let i=0;i<95;i++){
    const along=rand()*breakLen,sign=i%2?1:-1;
    dummy.position.copy(breakStart).addScaledVector(breakDir,along).addScaledVector(side,sign*(3.7+rand()*3.3));
    dummy.position.y=.09;dummy.rotation.set(-Math.PI/2,rand()*Math.PI*2,0);
    const scale=.15+rand()*.65;dummy.scale.set(scale,scale,scale);dummy.updateMatrix();foamFragments.setMatrixAt(i,dummy.matrix);
  }
  foamFragments.renderOrder=3;foamFragments.frustumCulled=false;group.add(foamFragments);
  // Small marker lights help express the breakwater's scale.
  const markerMat=mat('#394547');for(let i=0;i<5;i++){
    const p=breakStart.clone().addScaledVector(breakDir,8+i*13).addScaledVector(side,2.5);
    cylinder(0.08,0.11,2.2,markerMat,p.x,2.85,p.z);
    cylinder(0.22,0.22,0.25,mat('#e1d9b5'),p.x,3.95,p.z,group,12);
  }

  // Red Japanese harbour lighthouse, with a glazed lantern and real railings.
  const lighthouse=new THREE.Group();lighthouse.position.set(34,1.9,-65);group.add(lighthouse);
  const paintCanvas=document.createElement('canvas');paintCanvas.width=256;paintCanvas.height=768;
  const pc=paintCanvas.getContext('2d');
  const paintGradient=pc.createLinearGradient(0,0,256,0);
  paintGradient.addColorStop(0,'#a93f35');paintGradient.addColorStop(.42,'#cc5140');paintGradient.addColorStop(.7,'#c74a39');paintGradient.addColorStop(1,'#a83c32');
  pc.fillStyle=paintGradient;pc.fillRect(0,0,256,768);
  for(let i=0;i<9000;i++){
    const x=rand()*256,y=rand()*768;
    pc.fillStyle=rand()>.55?'rgba(245,213,176,.045)':'rgba(67,41,37,.068)';
    pc.fillRect(x,y,rand()*3+.3,rand()*7+.4);
  }
  // Vertical rain marks and mild oxidisation around real panel seams.
  for(let i=0;i<56;i++){
    const x=rand()*256,y=rand()*768;
    pc.strokeStyle=rand()>.45?'rgba(73,45,42,.12)':'rgba(249,194,159,.09)';
    pc.lineWidth=.5+rand()*2;pc.beginPath();pc.moveTo(x,y);pc.bezierCurveTo(x+rand()*4-2,y+14,x+rand()*5-2,y+50,x+rand()*3-1,y+60+rand()*140);pc.stroke();
  }
  for(let i=1;i<5;i++){const y=i*768/5;pc.fillStyle='rgba(70,34,31,.14)';pc.fillRect(0,y,256,1);pc.fillStyle='rgba(255,202,183,.1)';pc.fillRect(0,y+2,256,1);}
  const paintTexture=new THREE.CanvasTexture(paintCanvas);paintTexture.colorSpace=THREE.SRGBColorSpace;paintTexture.anisotropy=4;
  const red=new THREE.MeshStandardMaterial({map:paintTexture,color:'#f5e4dc',roughness:.78,metalness:.04,normalMap:stoneMaps.normalMap,normalScale:new THREE.Vector2(.075,.075)});
  const redLight=mat('#cb5444',{roughness:.68,metalness:.08});
  const cream=mat('#e8e4d6',{roughness:0.6});const metal=mat('#97372c',{metalness:0.38,roughness:0.49});
  cylinder(3.05,3.35,0.55,stoneTop,0,0.25,0,lighthouse);
  cylinder(2.31,2.48,0.9,cream,0,0.93,0,lighthouse);
  cylinder(1.58,2.27,15.5,red,0,8.96,0,lighthouse,64);
  cylinder(1.75,1.77,0.35,redLight,0,16.55,0,lighthouse,64);
  cylinder(2.52,2.27,0.42,cream,0,16.98,0,lighthouse,64);
  cylinder(2.59,2.59,0.13,redLight,0,17.25,0,lighthouse,64);
  // Narrow inset windows and door face the harbour.
  const windowMat=mat('#253a40',{roughness:0.22,metalness:0.25});
  for(const [y,r]of[[5.1,2.06],[10.1,1.82],[14.0,1.65]]){
    addMesh(new THREE.BoxGeometry(0.58,1.12,0.13),cream,0,y,r,lighthouse);
    addMesh(new THREE.BoxGeometry(0.38,0.88,0.15),windowMat,0,y,r+0.04,lighthouse);
  }
  // Small maintenance windows follow the tower's taper on the shore side.
  for(const [y,r]of[[7.5,1.95],[12.5,1.72]]){
    const frame=addMesh(new THREE.BoxGeometry(.51,.88,.11),cream,-r,y,.08,lighthouse);
    frame.rotation.y=Math.PI/2;
    const pane=addMesh(new THREE.BoxGeometry(.34,.69,.13),windowMat,-r-.055,y,.08,lighthouse);
    pane.rotation.y=Math.PI/2;
    addMesh(new THREE.BoxGeometry(.045,.69,.16),redLight,-r-.12,y,.08,lighthouse);
  }
  addMesh(new THREE.BoxGeometry(1.05,2.12,0.2),cream,0,2.1,2.27,lighthouse);
  addMesh(new THREE.BoxGeometry(0.81,1.87,0.22),redLight,0,2.09,2.34,lighthouse);
  const handle=addMesh(new THREE.SphereGeometry(0.055,10,6),mat('#b6a781',{metalness:0.8}),0.27,2.05,2.49,lighthouse);
  const glass=new THREE.MeshStandardMaterial({color:'#a0c7cf',metalness:0.33,roughness:0.16,transparent:true,opacity:0.58,side:THREE.DoubleSide});
  cylinder(1.61,1.61,2.35,glass,0,18.56,0,lighthouse,12);
  const lens=mat('#fff1ba',{emissive:'#ffd184',emissiveIntensity:0.65,metalness:0.28,roughness:0.2});
  cylinder(0.47,0.58,1.24,lens,0,18.65,0,lighthouse,24);
  for(let i=0;i<12;i++){const a=i/12*Math.PI*2;cylinder(0.055,0.055,2.42,redLight,Math.sin(a)*1.62,18.57,Math.cos(a)*1.62,lighthouse,8);}
  cylinder(1.91,1.91,0.23,redLight,0,19.85,0,lighthouse,48);
  cylinder(0.10,2.02,1.18,red,0,20.53,0,lighthouse,48);
  cylinder(0.055,0.075,1.30,metal,0,21.55,0,lighthouse,8);
  for(let i=0;i<24;i++){const a=i/24*Math.PI*2;cylinder(0.036,0.036,1.0,metal,Math.sin(a)*2.37,17.78,Math.cos(a)*2.37,lighthouse,6);}
  for(const y of [17.42,17.92,18.27]){const rail=new THREE.Mesh(new THREE.TorusGeometry(2.37,0.042,5,64),metal);rail.rotation.x=Math.PI/2;rail.position.y=y;lighthouse.add(rail);}
  // Slim service ladder on the seaward side, with hoop guards.
  for(const x of [-0.28,0.28])beam(new THREE.Vector3(x,1.8,-2.30),new THREE.Vector3(x,16.7,-1.68),0.033,metal,lighthouse,6);
  for(let i=0;i<34;i++){const t=i/33;beam(new THREE.Vector3(-0.28,1.8+t*14.9,-2.3+t*0.62),new THREE.Vector3(0.28,1.8+t*14.9,-2.3+t*0.62),0.025,metal,lighthouse,6);}
  // Cast iron expansion seams and small bolt heads break up the flat red shaft
  // in raking midday light; geometry is merged below into a few draw calls.
  const seamMetal=mat('#8e3933',{metalness:.36,roughness:.57});
  const boltMetal=mat('#afa79a',{metalness:.69,roughness:.41});
  for(const y of [3.65,7.15,10.65,14.3]){
    const radius=2.27-(y-1.21)/15.5*.69;
    const band=new THREE.Mesh(new THREE.TorusGeometry(radius+.025,.028,7,64),seamMetal);
    band.rotation.x=Math.PI/2;band.position.y=y;lighthouse.add(band);
    for(let i=0;i<20;i++){
      const a=i/20*Math.PI*2;
      const bolt=addMesh(new THREE.SphereGeometry(.035,7,5),boltMetal,Math.sin(a)*(radius+.045),y,Math.cos(a)*(radius+.045),lighthouse);
      bolt.scale.set(.95,.84,.58);
    }
  }
  // Collapse the many railings and ladder pieces into a few material batches.
  // This preserves their round silhouettes without paying one draw call per rung.
  const lighthouseBatches=new Map();
  for(const part of [...lighthouse.children]){
    if(!part.isMesh)continue;
    part.updateMatrix();
    const transformed=part.geometry.clone().applyMatrix4(part.matrix);
    const geo=transformed.index?transformed.toNonIndexed():transformed;
    if(!lighthouseBatches.has(part.material))lighthouseBatches.set(part.material,{p:[],n:[],uv:[]});
    const batch=lighthouseBatches.get(part.material),pos=geo.attributes.position,nrm=geo.attributes.normal,uv=geo.attributes.uv;
    for(let i=0;i<pos.count;i++){
      batch.p.push(pos.getX(i),pos.getY(i),pos.getZ(i));
      batch.n.push(nrm.getX(i),nrm.getY(i),nrm.getZ(i));
      batch.uv.push(uv?uv.getX(i):0,uv?uv.getY(i):0);
    }
    if(geo!==transformed)geo.dispose();transformed.dispose();part.geometry.dispose();lighthouse.remove(part);
  }
  for(const[material,batch]of lighthouseBatches){
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(batch.p,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(batch.n,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(batch.uv,2));geo.computeBoundingSphere();
    addMesh(geo,material,0,0,0,lighthouse);
  }

  // One small working fishing boat supplies scale and life to the open harbour.
  const trawler=new THREE.Group();trawler.position.set(-38,0,-99);trawler.rotation.y=-.31;group.add(trawler);
  const hullSections=[[-3.05,.08],[-2.45,.73],[-1.5,1.00],[0,1.11],[1.3,1.07],[2.35,.79],[2.95,.09]];
  const hullVertices=[],hullTriangles=[];
  for(const[z,w]of hullSections){
    hullVertices.push(-w,.42,z,-w*.82,-.19,z,0,-.62,z,w*.82,-.19,z,w,.42,z);
  }
  for(let k=0;k<hullSections.length-1;k++)for(let side=0;side<4;side++){
    const a=k*5+side,b=a+5;
    hullTriangles.push(a,b,a+1,a+1,b,b+1);
  }
  const hullGeometry=new THREE.BufferGeometry();
  hullGeometry.setAttribute('position',new THREE.Float32BufferAttribute(hullVertices,3));
  hullGeometry.setIndex(hullTriangles);hullGeometry.computeVertexNormals();
  const hull=new THREE.Mesh(hullGeometry,new THREE.MeshStandardMaterial({color:'#f0eee4',roughness:.61,metalness:.07,side:THREE.DoubleSide}));
  hull.castShadow=true;trawler.add(hull);
  addMesh(new THREE.BoxGeometry(1.73,.14,4.1),timberDark,0,.39,0,trawler);
  addMesh(new THREE.BoxGeometry(1.42,1.27,1.77),mat('#eeece3',{roughness:.53}),0,1.15,.82,trawler);
  addMesh(new THREE.BoxGeometry(1.74,.17,2.08),mat('#dcded5',{roughness:.47}),0,1.84,.8,trawler);
  const glassBoat=mat('#355e66',{roughness:.16,metalness:.24});
  addMesh(new THREE.BoxGeometry(1.10,.52,.035),glassBoat,0,1.41,-.07,trawler);
  for(const x of [-.73,.73]){
    addMesh(new THREE.BoxGeometry(.045,.49,1.14),glassBoat,x,1.42,.85,trawler);
    addMesh(new THREE.BoxGeometry(.035,.09,1.1),mat('#f3efe1'),x*.999,1.42,.85,trawler);
  }
  const boatMetal=mat('#a6aaa7',{metalness:.72,roughness:.32});
  for(const x of [-.84,.84]){
    beam(new THREE.Vector3(x,.48,-2.45),new THREE.Vector3(x,.94,-2.45),.025,boatMetal,trawler,8);
    beam(new THREE.Vector3(x,.48,2.42),new THREE.Vector3(x,.94,2.42),.025,boatMetal,trawler,8);
    beam(new THREE.Vector3(x,.94,-2.45),new THREE.Vector3(x,.94,2.42),.02,boatMetal,trawler,8);
  }
  beam(new THREE.Vector3(.28,1.9,1.05),new THREE.Vector3(.28,4.0,1.05),.035,boatMetal,trawler,10);
  const pennant=addMesh(new THREE.BoxGeometry(.8,.33,.025),mat('#cb5044'),.69,3.72,1.05,trawler);pennant.rotation.z=.08;
  const lifesaver=new THREE.Mesh(new THREE.TorusGeometry(.24,.067,8,20),mat('#d86650'));lifesaver.position.set(1.1,.69,-.25);lifesaver.rotation.y=Math.PI/2;trawler.add(lifesaver);
  const wakeMat=new THREE.MeshBasicMaterial({color:'#d9ebe7',transparent:true,opacity:.19,depthWrite:false});
  for(const s of [-1,1]){
    const points=[];
    for(let i=0;i<=24;i++){const t=i/24;points.push(new THREE.Vector3(s*(.72+t*1.65),.045,2.65+t*12));}
    const wake=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),36,.04,4,false),wakeMat);
    wake.renderOrder=3;trawler.add(wake);
  }

  // Atmospheric sunlight is calculated with the Three.js Preetham sky model.
  // A separate thin procedural cloud layer gives it more natural depth.
  const atmosphere=new Sky();atmosphere.scale.setScalar(1480);
  atmosphere.material.uniforms.sunPosition.value.copy(sunDirection);
  atmosphere.material.uniforms.turbidity.value=3.1;
  atmosphere.material.uniforms.rayleigh.value=2.4;
  atmosphere.material.uniforms.mieCoefficient.value=.0045;
  atmosphere.material.uniforms.mieDirectionalG.value=.79;
  atmosphere.renderOrder=-20;atmosphere.frustumCulled=false;scene.add(atmosphere);
  const skyUniforms={sunDir:{value:sunDirection},time:{value:0}};
  const clouds=new THREE.Mesh(new THREE.SphereGeometry(1420,32,20),new THREE.ShaderMaterial({
    side:THREE.BackSide,transparent:true,depthWrite:false,uniforms:skyUniforms,
    vertexShader:`varying vec3 vWorld;void main(){vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`
      uniform vec3 sunDir;uniform float time;varying vec3 vWorld;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float f=0.;float a=.55;for(int i=0;i<5;i++){f+=noise(p)*a;p=p*2.03+vec2(13.7,8.3);a*=.48;}return f;}
      void main(){
        vec3 d=normalize(vWorld-cameraPosition);
        vec2 p=d.xz/(max(d.y,.0)+.23)*2.8+vec2(time*.0011,-time*.0006);
        float n=fbm(p),detail=fbm(p*1.36+vec2(-.31,.27));
        float cover=smoothstep(.49,.69,mix(n,detail,.18));
        float cl=cover*smoothstep(.015,.115,d.y)*.93;
        float sd=max(dot(d,sunDir),0.);
        float light=smoothstep(.34,.67,detail+.13*sd);
        vec3 col=mix(vec3(.69,.77,.79),vec3(1.0,.985,.94),light);
        float silver=pow(sd,18.)*cover*(1.-cover)*.35;
        col+=vec3(1.,.91,.76)*silver;
        gl_FragColor=vec4(col,cl);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
  }));clouds.renderOrder=-19;clouds.frustumCulled=false;scene.add(clouds);

  const reflectionType=renderer?.extensions.has('EXT_color_buffer_float')?THREE.HalfFloatType:THREE.UnsignedByteType;
  const reflectionTarget = new THREE.WebGLRenderTarget(768,512,{type:reflectionType,depthBuffer:true});
  const reflectionCamera = new THREE.PerspectiveCamera();
  const textureMatrix = new THREE.Matrix4();
  const biasMatrix = new THREE.Matrix4().set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1);
  const seaNormals=makeSeaNormalTexture();
  const uniforms={
    time:{value:0},sunDir:{value:sunDirection},reflectionMap:{value:reflectionTarget.texture},reflectionMatrix:{value:textureMatrix},hasReflection:{value:0},
    waveAmplitude:{value:opts.waveAmplitude || 1},rippleNormals:{value:seaNormals}
  };
  // A non-uniform water grid concentrates geometry around the pier and casts.
  // The outer ocean remains one continuous draw call, all the way to the fog.
  const waterGeometry=new THREE.BufferGeometry();
  const waterSteps=224,waterPositions=new Float32Array((waterSteps+1)*(waterSteps+1)*3);
  const waterIndices=new Uint16Array(waterSteps*waterSteps*6);
  let vi=0,ii=0;
  for(let j=0;j<=waterSteps;j++){
    const v=j/waterSteps*2-1;
    const z=8+Math.sign(v)*900*Math.pow(Math.abs(v),2.85);
    for(let i=0;i<=waterSteps;i++){
      const u=i/waterSteps*2-1;
      const x=Math.sign(u)*900*Math.pow(Math.abs(u),2.85);
      waterPositions[vi++]=x;waterPositions[vi++]=0;waterPositions[vi++]=z;
    }
  }
  for(let j=0;j<waterSteps;j++)for(let i=0;i<waterSteps;i++){
    const a=j*(waterSteps+1)+i,b=a+1,c=a+waterSteps+1,d=c+1;
    waterIndices[ii++]=a;waterIndices[ii++]=c;waterIndices[ii++]=b;
    waterIndices[ii++]=b;waterIndices[ii++]=c;waterIndices[ii++]=d;
  }
  waterGeometry.setAttribute('position',new THREE.BufferAttribute(waterPositions,3));
  waterGeometry.setIndex(new THREE.BufferAttribute(waterIndices,1));
  const waterMaterial=new THREE.ShaderMaterial({uniforms,transparent:true,opacity:1,depthWrite:true,side:THREE.FrontSide,
    vertexShader:`
      uniform float time;uniform float waveAmplitude;uniform mat4 reflectionMatrix;
      varying vec3 vWorld;varying vec4 vReflect;
      float waves(vec2 p){return (
        sin(p.x*.17+p.y*.105+time*.57)*.092+
        sin(p.x*-.085+p.y*.29-time*.44)*.057+
        sin(p.x*.37+p.y*.19+time*1.03)*.022+
        sin(p.x*-.57+p.y*.43-time*.78)*.011+
        sin(p.x*.052+p.y*.048+time*.28)*.067
      )*waveAmplitude;}
      void main(){vec3 p=position;p.y+=waves(p.xz);vec4 world=modelMatrix*vec4(p,1.);vWorld=world.xyz;vReflect=reflectionMatrix*world;gl_Position=projectionMatrix*viewMatrix*world;}`,
    fragmentShader:`
      uniform float time;uniform float waveAmplitude;uniform vec3 sunDir;uniform sampler2D reflectionMap;uniform sampler2D rippleNormals;uniform float hasReflection;
      varying vec3 vWorld;varying vec4 vReflect;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      void main(){
        vec2 p=vWorld.xz;float t=time;
        float c1=cos(p.x*.17+p.y*.105+t*.57);
        float c2=cos(p.x*-.085+p.y*.29-t*.44);
        float c3=cos(p.x*.37+p.y*.19+t*1.03);
        float c4=cos(p.x*-.57+p.y*.43-t*.78);
        float c5=cos(p.x*.052+p.y*.048+t*.28);
        vec2 slope=vec2(
          c1*.01564-c2*.004845+c3*.00814-c4*.00627+c5*.003484,
          c1*.00966+c2*.01653+c3*.00418+c4*.00473+c5*.003216);
        float n1=noise(p*.81+vec2(t*.13,-t*.095));
        float n2=noise(p*1.68+vec2(-t*.11,t*.14));
        slope+=vec2(n1-.5,n2-.5)*.12;
        slope+=vec2(sin(p.x*2.17+p.y*1.87+t*1.7),cos(p.x*-2.42+p.y*1.73-t*1.5))*.013;
        vec2 ripA=texture2D(rippleNormals,p*.095+vec2(t*.019,-t*.011)).rg*2.-1.;
        vec2 ripB=texture2D(rippleNormals,p*.18+vec2(-t*.016,t*.024)).rg*2.-1.;
        slope+=ripA*.072+ripB*.045;
        vec3 N=normalize(vec3(-slope.x*waveAmplitude,1.,-slope.y*waveAmplitude));
        vec3 V=normalize(cameraPosition-vWorld);float ndv=max(dot(N,V),0.);
        float fres=.035+.965*pow(1.-ndv,4.5);
        float dist=length(cameraPosition.xz-p);
        vec3 shallow=vec3(.035,.37,.40);vec3 deep=vec3(.012,.20,.31);
        vec3 base=mix(shallow,deep,smoothstep(4.,65.,dist));
        float cloudShade=noise(p*.006+vec2(t*.008,-t*.005));
        base*=.94+.095*cloudShade;
        // The disturbed shallows along the rock wall are lighter and clouded.
        vec2 a=vec2(91.,-17.),b=vec2(31.,-70.);
        vec2 ba=b-a;
        float rockDist=length(p-a-ba*clamp(dot(p-a,ba)/dot(ba,ba),0.,1.));
        float shore=1.-smoothstep(4.,21.,rockDist);
        base=mix(base,vec3(.055,.40,.40),shore*.32);
        float patterns=sin(p.x*1.1+p.y*.7+t*.5)*sin(p.x*-.6+p.y*1.3-t*.42);
        float caustics=pow(clamp(patterns,.0,1.),6.);base+=vec3(.055,.12,.095)*caustics*exp(-dist*.035)*ndv;
        vec3 reflected=reflect(-V,N);vec3 skyCol=mix(vec3(.66,.82,.87),vec3(.14,.44,.69),pow(max(reflected.y,0.),.4));
        vec2 uv=vReflect.xy/vReflect.w+slope*.026/(1.+dist*.015);
        if(hasReflection>.5&&uv.x>0.&&uv.x<1.&&uv.y>0.&&uv.y<1.)skyCol=mix(skyCol,texture2D(reflectionMap,uv).rgb,.88);
        vec3 col=mix(base,skyCol,fres*.82+.12);
        vec3 halfV=normalize(sunDir+V);float sunDot=max(dot(N,halfV),0.);
        float spec=pow(sunDot,330.);
        col+=vec3(1.,.97,.83)*spec*3.1;
        float fleck=pow(sunDot,35.)*(.07+.14*smoothstep(.47,.86,n1+n2*.3));
        col+=vec3(1.,.94,.78)*fleck;
        // Small bright capillary glints come and go independently of the broad swell.
        float micro=sin(p.x*6.3+p.y*4.7+t*2.15)*sin(p.x*-5.1+p.y*7.2-t*1.85);
        float glitter=pow(max(0.,micro*.5+.5),23.)*pow(max(dot(N,sunDir),0.),7.)*pow(1.-ndv,.42);
        col+=vec3(.33,.38,.35)*glitter*.23;
        float surgeFoam=shore*pow(smoothstep(.46,.82,n1+.16*n2),2.);
        col+=vec3(.45,.56,.48)*surgeFoam*.26;
        float fog=1.-exp(-dist*.0018);col=mix(col,vec3(.58,.77,.82),fog);
        gl_FragColor=vec4(col,.88+fres*.12);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
  });
  const water=new THREE.Mesh(waterGeometry,waterMaterial);water.name='Reflecting turquoise ocean';water.frustumCulled=false;water.renderOrder=2;scene.add(water);
  // A sandy seabed reveals blue-green depth and the fish close to the dock.
  const seabed=addMesh(new THREE.PlaneGeometry(160,160),mat('#88a797'),0,-7,-35);seabed.rotation.x=-Math.PI/2;seabed.castShadow=false;
  const seabedStones=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1,1),mat('#b4b2a3',{roughness:1}),100);
  for(let i=0;i<100;i++){
    const x=(rand()-.5)*115,z=-4-rand()*105;
    const r=.36+rand()*1.9;
    dummy.position.set(x,-6.75+rand()*.34,z);
    dummy.rotation.set(rand()*.6,rand()*6.28,rand()*.6);
    dummy.scale.set(r,.18+rand()*.38,r*(.67+rand()*.62));dummy.updateMatrix();seabedStones.setMatrixAt(i,dummy.matrix);
    seabedStones.setColorAt(i,new THREE.Color().setHSL(.11+rand()*.12,.11+rand()*.1,.47+rand()*.23));
  }
  seabedStones.castShadow=false;group.add(seabedStones);

  // Narrow foam ribbons at the breakwater foot.
  const foamMaterial=new THREE.MeshBasicMaterial({color:'#e2efdb',transparent:true,opacity:.19,depthWrite:false});
  const foamCurves=[];
  for(const s of [-1,1]) {
    const points=[];
    for(let i=0;i<=42;i++){const p=breakStart.clone().addScaledVector(breakDir,i/42*breakLen).addScaledVector(side,s*(4.2+Math.sin(i*1.7)*.23));p.y=.055;points.push(p);}
    const foam=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),100,.085,5,false),foamMaterial);foam.renderOrder=3;group.add(foam);foamCurves.push(foam);
  }

  // Gulls use two articulated curved wings; the silhouettes remain delicate.
  const gulls=[];const gullMat=mat('#f5f4e9',{side:THREE.DoubleSide});
  const gullDark=mat('#465354',{side:THREE.DoubleSide});
  function gullWing(sign) {
    const geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,sign*.48,.10,-.04,sign*1.05,-.02,.12,sign*.51,.03,.28,0,0,.14],3));
    geo.setIndex([0,1,3,1,2,3,0,3,4]);geo.computeVertexNormals();return new THREE.Mesh(geo,gullMat);
  }
  for(let i=0;i<7;i++){
    const bird=new THREE.Group();
    const body=new THREE.Mesh(new THREE.SphereGeometry(1,8,6),gullMat);body.scale.set(.12,.13,.36);bird.add(body);
    const l=gullWing(-1),r=gullWing(1);bird.add(l,r);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.10,8,6),gullMat);head.position.set(0,.06,-.32);bird.add(head);
    const beak=new THREE.Mesh(new THREE.ConeGeometry(.035,.16,6),mat('#baa55b'));beak.rotation.x=-Math.PI/2;beak.position.set(0,.05,-.44);bird.add(beak);
    const scale=.55+rand()*.24;bird.scale.setScalar(scale);group.add(bird);
    gulls.push({bird,l,r,phase:rand()*Math.PI*2,radius:24+rand()*55,speed:.025+rand()*.015,height:14+rand()*18,cx:-25+rand()*70,cz:-75-rand()*30});
  }
  let frame=0;
  const cameraDirection=new THREE.Vector3(),cameraWorldPosition=new THREE.Vector3(),target=new THREE.Vector3();
  const reflectionPlane=new THREE.Plane(),clipPlane=new THREE.Vector4(),clipCorner=new THREE.Vector4();
  const waterNormal=new THREE.Vector3(0,1,0),waterOrigin=new THREE.Vector3();
  function renderReflection(camera) {
    if(!renderer || renderer.xr.isPresenting || !camera) return;
    camera.updateWorldMatrix(true,false);
    cameraWorldPosition.setFromMatrixPosition(camera.matrixWorld);
    if(cameraWorldPosition.y<.15)return;
    // Copy only the projection and pose, avoiding Camera.copy()'s userData cloning.
    reflectionCamera.projectionMatrix.copy(camera.projectionMatrix);
    reflectionCamera.near=camera.near;reflectionCamera.far=camera.far;
    reflectionCamera.layers.mask=camera.layers.mask;
    reflectionCamera.position.copy(cameraWorldPosition);reflectionCamera.position.y=-cameraWorldPosition.y;
    cameraDirection.setFromMatrixColumn(camera.matrixWorld,2).negate();
    target.copy(cameraWorldPosition).add(cameraDirection);target.y=-target.y;
    reflectionCamera.up.setFromMatrixColumn(camera.matrixWorld,1).reflect(waterNormal);
    reflectionCamera.lookAt(target);reflectionCamera.updateMatrixWorld();
    textureMatrix.copy(biasMatrix).multiply(reflectionCamera.projectionMatrix).multiply(reflectionCamera.matrixWorldInverse);

    // Standard planar-reflection oblique clipping: reflect above-water scenery only.
    // Texture projection intentionally uses the unmodified projection matrix above.
    reflectionPlane.setFromNormalAndCoplanarPoint(waterNormal,waterOrigin).applyMatrix4(reflectionCamera.matrixWorldInverse);
    clipPlane.set(reflectionPlane.normal.x,reflectionPlane.normal.y,reflectionPlane.normal.z,reflectionPlane.constant);
    const pe=reflectionCamera.projectionMatrix.elements;
    clipCorner.set((Math.sign(clipPlane.x)+pe[8])/pe[0],(Math.sign(clipPlane.y)+pe[9])/pe[5],-1,(1+pe[10])/pe[14]);
    clipPlane.multiplyScalar(2/clipPlane.dot(clipCorner));
    pe[2]=clipPlane.x;pe[6]=clipPlane.y;pe[10]=clipPlane.z+1-.001;pe[14]=clipPlane.w;
    reflectionCamera.projectionMatrixInverse.copy(reflectionCamera.projectionMatrix).invert();

    const oldTarget=renderer.getRenderTarget();const shadowAuto=renderer.shadowMap.autoUpdate;
    const oldFace=renderer.getActiveCubeFace(),oldMip=renderer.getActiveMipmapLevel();
    const oldXr=renderer.xr.enabled;const oldTone=renderer.toneMapping,oldVisible=water.visible;
    water.visible=false;renderer.xr.enabled=false;renderer.shadowMap.autoUpdate=false;
    // Keep the reflection in linear scene space; the final water pass handles output colour.
    renderer.toneMapping=THREE.NoToneMapping;
    try{
      renderer.setRenderTarget(reflectionTarget);
      renderer.state.buffers.depth.setMask(true);
      if(!renderer.autoClear)renderer.clear();
      renderer.render(scene,reflectionCamera);
      uniforms.hasReflection.value=1;
    }finally{
      renderer.setRenderTarget(oldTarget,oldFace,oldMip);
      renderer.shadowMap.autoUpdate=shadowAuto;renderer.xr.enabled=oldXr;renderer.toneMapping=oldTone;water.visible=oldVisible;
      if(camera.viewport)renderer.state.viewport(camera.viewport);
    }
  }
  const waterHeight=(x,z,t=0)=>(
    Math.sin(x*.17+z*.105+t*.57)*.092+
    Math.sin(x*-.085+z*.29-t*.44)*.057+
    Math.sin(x*.37+z*.19+t*1.03)*.022+
    Math.sin(x*-.57+z*.43-t*.78)*.011+
    Math.sin(x*.052+z*.048+t*.28)*.067
  )*uniforms.waveAmplitude.value;
  function update(dt,time,camera) {
    uniforms.time.value=time;skyUniforms.time.value=time;
    if(camera){clouds.position.copy(camera.position);atmosphere.position.copy(camera.position);}
    for(let i=0;i<pilePositions.length;i++){
      const [x,z]=pilePositions[i];
      dummy.position.set(x,waterHeight(x,z,time)+.052,z);
      dummy.rotation.set(-Math.PI/2,0,0);
      const swell=1.02+.13*Math.sin(time*1.1+i*1.2);
      dummy.scale.set(swell,swell,1);dummy.updateMatrix();pileWakes.setMatrixAt(i,dummy.matrix);
    }
    pileWakes.instanceMatrix.needsUpdate=true;
    foamMaterial.opacity=.085+.03*Math.sin(time*.7);
    trawler.position.y=waterHeight(trawler.position.x,trawler.position.z,time)+Math.sin(time*.63)*.045;
    trawler.rotation.z=Math.sin(time*.78)*.017;
    trawler.rotation.x=Math.sin(time*.69+.7)*.015;
    for(const g of gulls){const a=time*g.speed+g.phase;g.bird.position.set(g.cx+Math.cos(a)*g.radius,g.height+Math.sin(a*2.7)*1.2,g.cz+Math.sin(a)*g.radius*.45);g.bird.rotation.y=-a-Math.PI/2;g.bird.rotation.z=Math.sin(a)*.11;const flap=Math.sin(time*3.2+g.phase)*.22*(Math.sin(time*.22+g.phase)>.3?1:.18);g.l.rotation.z=-flap;g.r.rotation.z=flap;}
    if(renderer && !renderer.xr.isPresenting && frame++%3===0) renderReflection(camera);
    if(renderer?.xr.isPresenting)uniforms.hasReflection.value=0;
  }
  return {update,waterHeight,pierY,water,lighthouse,group,renderReflection,
    dispose(){reflectionTarget.dispose();environmentTarget?.dispose();seaNormals.dispose();group.traverse(o=>{if(o.geometry)o.geometry.dispose();});waterGeometry.dispose();waterMaterial.dispose();}
  };
}
