// Renderer-independent fishing simulation. All dimensions are in metres/seconds.
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, t) => a + (b - a) * t;
const finite = (x, fallback) => Number.isFinite(x) ? x : fallback;
const smooth = t => t * t * (3 - 2 * t);

const FISH = {
  madai: { length: [24, 68], weight: [.35, 4.8], difficulty: 1.02 },
  aji: { length: [16, 38], weight: [.07, .65], difficulty: .84 },
  suzuki: { length: [38, 92], weight: [.55, 7.2], difficulty: 1.12 },
  saba: { length: [22, 48], weight: [.16, 1.35], difficulty: .92 },
  aori: { length: [15, 42], weight: [.2, 2.8], difficulty: .96 },
};

export class FishingEngine {
  constructor({ onEvent = () => {}, random = Math.random } = {}) {
    this.onEvent = onEvent;
    this.random = random;
    this.mode = 'lure';
    this.drag = .5;
    this.sessionCatch = 0;
    this.casts = 0;
    this._clock = 0;
    this.lastCatch = null;
    this.bobber = { x: 0, y: 3.2, z: 6 };
    this.fishPos = { x: 0, y: -1, z: -20 };
    this.reset();
  }

  _rand() { return clamp(finite(this.random(), .5), 0, .999999); }
  _emit(type, data = {}) { this.onEvent({ type, state: this.state, mode: this.mode, ...data }); }

  reset() {
    this.state = 'ready';
    this.stateTime = 0;
    this.reeling = false;
    this.tension = 0;
    this.progress = 0;
    this.distance = 0;
    this.depth = 0;
    this.rodBend = .025;
    this.strikeLeft = 0;
    this.surge = 0;
    this.lureAction = 0;
    this.fishStamina = 1;
    this.slackTime = 0;
    this.overloadTime = 0;
    this.escapeReason = '';
    this.speciesId = null;
    this.status = 'Aim toward open water';
    this._jigCooldown = 0;
    this._reelPressure = 0;
    this._biteCountdown = 0;
    this._origin = { x: 0, y: 3.2, z: 6 };
    Object.assign(this.bobber, this._origin);
    return true;
  }

  release() { return this.reset(); }

  setMode(mode) {
    if (mode !== 'lure' && mode !== 'float') return false;
    if (mode === this.mode) return true;
    if (this.state === 'fighting' || this.state === 'bite' || this.state === 'casting') return false;
    this.mode = mode;
    if (this.state === 'waiting') this.reset();
    return true;
  }

  setDrag(value) { this.drag = clamp(finite(Number(value), this.drag), .05, .95); }
  setReeling(value) { this.reeling = !!value; }

  cast({ power = .65, direction = { x: 0, y: .05, z: -1 }, origin = { x: 0, y: 3.2, z: 6 } } = {}) {
    if (this.state !== 'ready' && this.state !== 'escaped') return false;
    this.reset();
    this.lastCatch = null;
    this.casts++;
    power = clamp(finite(power, .65), .08, 1);
    this._origin = {
      x: finite(origin.x, 0), y: Math.max(1, finite(origin.y, 3.2)), z: finite(origin.z, 6),
    };
    // The player stands at a fixed pier. Keep a rearward aim out of the timber deck.
    let dx = finite(direction.x, 0);
    let dz = Math.min(-.12, finite(direction.z, -1));
    const n = Math.hypot(dx, dz) || 1;
    dx /= n; dz /= n;
    const range = 14 + power * 39;
    this._target = { x: this._origin.x + dx * range, y: .04, z: this._origin.z + dz * range };
    // Very sideways throws still need enough clearance beyond the front edge.
    this._target.z = Math.min(1.2, this._target.z);
    this._castDuration = .95 + power * .55;
    this._castArch = 3.3 + power * 3.8;
    this._biteCountdown = 7 + this._rand() * 7;
    this._driftPhase = this._rand() * Math.PI * 2;
    this._castDirection = { x: dx, z: dz };
    this.distance = Math.hypot(this._target.x - this._origin.x, this._target.z - this._origin.z);
    this._initialDistance = this.distance;
    this.state = 'casting';
    this.status = 'Casting';
    Object.assign(this.bobber, this._origin);
    this._emit('cast', { power, target: { ...this._target }, distance: this.distance });
    return true;
  }

  jig() {
    if (this.state !== 'waiting' || this.mode !== 'lure' || this._jigCooldown > 0) return false;
    this.lureAction = 1;
    this.depth = Math.max(.25, this.depth - .8);
    this._biteCountdown = Math.max(.55, this._biteCountdown - 1.05);
    this._jigCooldown = .7;
    this.status = 'Jigging · let it flutter';
    this._emit('jig', { position: { ...this.bobber } });
    return true;
  }

  _chooseFish() {
    // Species and sizes are game values, selected differently for the two rigs.
    const r = this._rand();
    if (this.mode === 'float') this.speciesId = r < .36 ? 'madai' : r < .73 ? 'aji' : r < .90 ? 'saba' : 'suzuki';
    else this.speciesId = r < .27 ? 'madai' : r < .45 ? 'aji' : r < .70 ? 'suzuki' : r < .84 ? 'saba' : 'aori';
    const def = FISH[this.speciesId];
    const size = .16 + this._rand() * .8;
    this._fishData = {
      speciesId: this.speciesId,
      lengthCm: Math.round(lerp(...def.length, size)),
      weightKg: Math.round(lerp(...def.weight, Math.pow(size, 2.4)) * 100) / 100,
      mode: this.mode,
    };
    this._difficulty = def.difficulty * (.9 + .15 * size);
  }

  hook() {
    if (this.state !== 'bite' || this.strikeLeft <= 0) return false;
    this.state = 'fighting';
    this.stateTime = 0;
    this.strikeLeft = 0;
    this.progress = .035;
    this.tension = .4;
    this.rodBend = .65;
    this._fightStartDistance = Math.max(9, this.distance);
    this._fightStartDepth = Math.max(.7, this.depth);
    this._reelPressure = 0;
    this.reeling = false;
    this.slackTime = 0;
    this.overloadTime = 0;
    this.status = 'Fish on · hold to reel';
    this._emit('hook', { ...this._fishData });
    return true;
  }

  _escape(reason) {
    if (this.state === 'escaped' || this.state === 'ready') return;
    this.state = 'escaped';
    this.stateTime = 0;
    this.reeling = false;
    this.strikeLeft = 0;
    this.escapeReason = reason;
    this.status = reason;
    this._emit('escape', { reason, speciesId: this.speciesId });
  }

  _catch() {
    this.state = 'caught';
    this.stateTime = 0;
    this.reeling = false;
    this.progress = 1;
    this.sessionCatch++;
    this._landingStart = { ...this.bobber };
    // The caught model lies on its side: use its narrow body radius above the
    // 1.65 m deck, rather than suspending every species at the same high point.
    const landingSize = Math.max(.38, this._fishData.lengthCm / 100);
    this._landingY = 1.65 + Math.max(.035, landingSize * (this.speciesId === 'aori' ? .13 : .09));
    this.lastCatch = { ...this._fishData, number: this.sessionCatch, cast: this.casts };
    this.status = 'Beautiful catch';
    this._emit('catch', { ...this.lastCatch });
  }

  update(dt, time = 0) {
    dt = clamp(finite(dt, 0), 0, .05);
    if (!dt) return;
    this._clock += dt;
    this.stateTime += dt;
    this._jigCooldown = Math.max(0, this._jigCooldown - dt);
    this.lureAction = Math.max(0, this.lureAction - dt * 1.35);
    const t = this._clock;

    if (this.state === 'ready') {
      this.rodBend = lerp(this.rodBend, .025, 1 - Math.exp(-dt * 5));
      return;
    }

    if (this.state === 'casting') {
      const p = clamp(this.stateTime / this._castDuration);
      this.bobber.x = lerp(this._origin.x, this._target.x, p);
      this.bobber.z = lerp(this._origin.z, this._target.z, p);
      this.bobber.y = lerp(this._origin.y, this._target.y, p) + this._castArch * 4 * p * (1 - p);
      this.rodBend = .06 + Math.sin(p * Math.PI) * .5;
      if (p >= 1) {
        this.state = 'waiting';
        this.stateTime = 0;
        this.depth = this.mode === 'float' ? 1.2 : .3;
        this.status = this.mode === 'float' ? 'Watch the float' : 'Jig to attract a fish';
        this._emit('splash', { position: { ...this.bobber } });
      }
      return;
    }

    if (this.state === 'waiting' || this.state === 'bite') {
      if (this.state === 'waiting') {
        this._biteCountdown -= dt * (this.reeling && this.mode === 'lure' ? 1.35 : 1);
        this.depth = this.mode === 'float' ? 1.2 : clamp(this.depth + dt * .18 - this.lureAction * dt * .6, .25, 6);
        if (this.reeling && this.mode === 'lure') {
          const pull = dt * .45;
          this._target.x -= this._castDirection.x * pull;
          this._target.z -= this._castDirection.z * pull;
          this.distance = Math.hypot(this._target.x - this._origin.x, this._target.z - this._origin.z);
        }
        this.rodBend = .035 + this.lureAction * .22;
        this.tension = .035 + this.lureAction * .07;
        if (this._biteCountdown <= 0) {
          this._chooseFish();
          this.state = 'bite';
          this.stateTime = 0;
          this.strikeLeft = 4.5;
          this.reeling = false;
          this.status = 'ヒット！ · Set the hook';
          this._emit('bite', { ...this._fishData, position: { ...this.bobber } });
        }
      } else {
        this.strikeLeft = Math.max(0, 4.5 - this.stateTime);
        this.rodBend = .1 + Math.abs(Math.sin(t * 13)) * .16;
        this.tension = .2;
        if (this.strikeLeft <= 0) { this._escape('Missed the bite · cast again'); return; }
      }
      const bite = this.state === 'bite';
      this.bobber.x = this._target.x + Math.sin(t * .65 + this._driftPhase) * .14 + (bite ? Math.sin(t * 12) * .14 : 0);
      this.bobber.z = this._target.z + Math.cos(t * .42 + this._driftPhase) * .13;
      // A float stays on the surface; the jig and its attachment follow depth.
      this.bobber.y = this.mode === 'float' ? .075 + Math.sin(t * 2.1) * .035 : -this.depth;
      if (bite) this.bobber.y -= .2 + Math.abs(Math.sin(t * 8)) * .16;
      this.fishPos.x = this.bobber.x;
      this.fishPos.y = -this.depth - .25;
      this.fishPos.z = this.bobber.z;
      return;
    }

    if (this.state === 'fighting') {
      const f = this.stateTime;
      this.fishStamina = Math.max(.18, 1 - this.progress * .79);
      // A readable, slow pull/recover rhythm gives the angler time to react.
      const wave = Math.max(0, Math.sin(f * .83 - 1.4));
      this.surge = wave * wave * (.72 + this.fishStamina * .28);
      this._reelPressure = clamp(this._reelPressure + dt * (this.reeling ? .06 : -.42));
      const resting = .12 + this.drag * .19 + this.surge * .22;
      const pulling = .44 + this.drag * .43 + this.surge * .57 + this._reelPressure * .16;
      const targetTension = clamp(this.reeling ? pulling : resting, .10, 1);
      this.tension = lerp(this.tension, targetTension, 1 - Math.exp(-dt * 3.4));
      this.tension = clamp(this.tension, 0, 1);

      if (this.tension > .965) this.overloadTime += dt;
      else this.overloadTime = Math.max(0, this.overloadTime - dt * 2.5);
      if (this.overloadTime > 1.7) { this._escape('Line snapped · release the reel during a strong pull'); return; }

      // Resting during a run is intended. Only sustained very loose drag loses a fish.
      if (!this.reeling && this.drag < .14 && this.tension < .4) this.slackTime += dt;
      else this.slackTime = Math.max(0, this.slackTime - dt * 2);
      if (this.slackTime > 7) { this._escape('Hook slipped · keep a little tension on the line'); return; }

      if (this.reeling) {
        const efficiency = (.58 + this.drag * .84) * (1 - .58 * this.surge);
        this.progress += dt * .065 * efficiency / this._difficulty;
      } else {
        this.progress -= dt * (.003 + .011 * this.surge) * (1.08 - this.drag);
      }
      this.progress = clamp(this.progress);
      this.distance = lerp(this._fightStartDistance, 3, smooth(this.progress));
      this.depth = lerp(this._fightStartDepth, .15, smooth(this.progress));
      const lateral = Math.sin(f * 1.13) * (1.2 + this.surge * 2.2) * (1 - this.progress * .8);
      this.bobber.x = this._origin.x + this._castDirection.x * this.distance - this._castDirection.z * lateral;
      this.bobber.z = this._origin.z + this._castDirection.z * this.distance + this._castDirection.x * lateral;
      this.bobber.y = -this.depth + Math.sin(t * 7.5) * .07 * this.surge;
      Object.assign(this.fishPos, this.bobber);
      this.rodBend = clamp(.17 + this.tension * .78 + Math.sin(t * 15) * this.surge * .035);
      this.status = this.tension > .86 ? 'Ease off · release to lower tension' : this.surge > .6 ? 'Fish is pulling · let it run' : this.reeling ? 'Reeling in' : 'Hold to reel · tension is safe';
      if (this.progress >= 1) this._catch();
      return;
    }

    if (this.state === 'caught') {
      const p = clamp(this.stateTime / 1.05);
      this.bobber.x = lerp(this._landingStart.x, this._origin.x + .65, smooth(p));
      this.bobber.z = lerp(this._landingStart.z, this._origin.z + .35, smooth(p));
      this.bobber.y = lerp(this._landingStart.y, this._landingY, smooth(p)) + Math.sin(p * Math.PI) * 1.45;
      Object.assign(this.fishPos, this.bobber);
      this.tension = lerp(this.tension, .1, 1 - Math.exp(-dt * 5));
      this.rodBend = lerp(this.rodBend, .08, 1 - Math.exp(-dt * 4));
      return;
    }

    if (this.state === 'escaped') {
      this.tension *= Math.exp(-dt * 5);
      this.rodBend *= Math.exp(-dt * 4);
      if (this.stateTime > 3.2) this.reset();
    }
  }
}
