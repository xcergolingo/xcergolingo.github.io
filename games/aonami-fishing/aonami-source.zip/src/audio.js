// Quiet, asset-free seaside audio. AudioContext is created only by start().
export class CoastalAudio {
  constructor() {
    this.context = null;
    this.master = null;
    this.muted = false;
    this.started = false;
    this.tick = 0;
    this.gullTimer = 14;
    this.time = 0;
  }

  async start() {
    const AudioContext = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AudioContext) return false;
    try {
      if (!this.context) {
        const ctx = this.context = new AudioContext();
        this.master = ctx.createGain();
        this.master.gain.value = this.muted ? 0 : .54;
        this.master.connect(ctx.destination);
        this.noise = ctx.createBuffer(1, ctx.sampleRate * 5, ctx.sampleRate);
        const data = this.noise.getChannelData(0);
        let p = 0;
        for (let i = 0; i < data.length; i++) { p = p * .86 + (Math.random() * 2 - 1) * .14; data[i] = p * 2.2; }
        const surf = ctx.createBufferSource(); surf.buffer = this.noise; surf.loop = true;
        const filter = this.surfFilter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 1650; filter.Q.value = .45;
        const gain = this.surfGain = ctx.createGain(); gain.gain.value = .16;
        surf.connect(filter); filter.connect(gain); gain.connect(this.master); surf.start();
        const wind = ctx.createBufferSource(); wind.buffer = this.noise; wind.loop = true; wind.playbackRate.value = .66;
        const windFilter = ctx.createBiquadFilter(); windFilter.type = 'bandpass'; windFilter.frequency.value = 340; windFilter.Q.value = .6;
        const windGain = ctx.createGain(); windGain.gain.value = .045;
        wind.connect(windFilter); windFilter.connect(windGain); windGain.connect(this.master); wind.start();
      }
      if (this.context.state === 'suspended') await this.context.resume();
      this.started = true;
      return true;
    } catch (_) { return false; }
  }

  setMuted(muted) {
    this.muted = !!muted;
    if (this.master) this.master.gain.setTargetAtTime(this.muted ? 0 : .54, this.context.currentTime, .05);
  }

  tone(freq, duration, volume = .1, when = 0, end = freq, type = 'sine') {
    const ctx = this.context;
    if (!ctx || ctx.state !== 'running') return;
    const t = ctx.currentTime + when;
    const oscillator = ctx.createOscillator(), gain = ctx.createGain();
    oscillator.type = type; oscillator.frequency.setValueAtTime(freq, t);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(30, end), t + duration);
    gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(volume, t + Math.min(.018, duration * .18)); gain.gain.exponentialRampToValueAtTime(.0001, t + duration);
    oscillator.connect(gain); gain.connect(this.master); oscillator.start(t); oscillator.stop(t + duration + .02);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }

  burst(duration, volume, frequency, endFrequency = frequency, delay = 0) {
    const ctx = this.context;
    if (!ctx || !this.noise || ctx.state !== 'running') return;
    const t = ctx.currentTime + delay;
    const source = ctx.createBufferSource(), filter = ctx.createBiquadFilter(), gain = ctx.createGain();
    source.buffer = this.noise;
    filter.type = 'bandpass'; filter.frequency.setValueAtTime(frequency, t); filter.frequency.exponentialRampToValueAtTime(Math.max(50, endFrequency), t + duration); filter.Q.value = .72;
    gain.gain.setValueAtTime(.0001, t); gain.gain.exponentialRampToValueAtTime(Math.max(.0002, volume), t + .02); gain.gain.exponentialRampToValueAtTime(.0001, t + duration);
    source.connect(filter); filter.connect(gain); gain.connect(this.master); source.start(t, Math.random()); source.stop(t + duration + .01);
    source.onended = () => { source.disconnect(); filter.disconnect(); gain.disconnect(); };
  }

  effect(name) {
    if (!this.context || this.muted) return;
    if (name === 'cast') { this.burst(.45, .24, 1000, 2600); this.tone(260, .13, .024, 0, 110); }
    if (name === 'splash') { this.burst(.42, .48, 2000, 600); this.tone(180, .19, .055, 0, 65); }
    if (name === 'bite') { this.tone(880, .15, .20); this.tone(1320, .4, .17, .13); this.burst(.12, .08, 3300, 800); }
    if (name === 'hook') { this.burst(.14, .18, 1800, 700); this.tone(140, .12, .07, 0, 80); }
    if (name === 'catch') { this.burst(.5, .24, 1600, 500); this.tone(523.25, .5, .13, .06); this.tone(659.25, .65, .11, .22); this.tone(783.99, .9, .11, .36); }
    if (name === 'break' || name === 'lost') { this.burst(.14, .14, 2900, 1200); this.tone(330, .34, .09, .05, 170); }
    if (name === 'reel') this.tone(1350, .018, .035, 0, 650, 'triangle');
    if (name === 'gull') {
      this.tone(1180, .16, .022, 0, 1480, 'triangle');
      this.tone(1450, .30, .019, .13, 850, 'triangle');
      this.tone(1100, .23, .012, .48, 780, 'triangle');
    }
  }

  update(dt, { state = '', reeling = false, tension = 0 } = {}) {
    if (!this.context || !this.started || this.context.state !== 'running') return;
    this.time += dt;
    const t = this.time;
    this.surfGain.gain.setTargetAtTime(.145 + Math.sin(t * .43) * .041 + Math.sin(t * .19 + 1) * .018, this.context.currentTime, .2);
    this.surfFilter.frequency.setTargetAtTime(1300 + 450 * Math.sin(t * .31), this.context.currentTime, .2);
    if (reeling) {
      this.tick -= dt;
      if (this.tick <= 0) {
        this.effect('reel'); this.tick = .085 + Math.min(.06, tension * .05);
      }
    } else this.tick = 0;
    this.gullTimer -= dt;
    if (this.gullTimer <= 0) { this.effect('gull'); this.gullTimer = 22 + Math.random() * 22; }
  }
}
