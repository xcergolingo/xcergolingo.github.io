import * as THREE from 'three';
import { createCoast } from './coast.js';
import { SPECIES, buildFish, createShoals } from './fish.js';
import { FishingEngine } from './fishing.js';
import { CoastalAudio } from './audio.js';
import { createRod } from './rod.js';
import { LearningSession, parseVocabulary, DEFAULT_VOCABULARY, shouldSpeakOnReel, readVocabularyTransfer } from './learning.js';

const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const icons={
 sound:'<path d="M11 4 6 8H3v8h3l5 4V4Z"/><path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
 mute:'<path d="M11 4 6 8H3v8h3l5 4V4Z"/><path d="m16 9 5 6m0-6-5 6"/>',
 book:'<path d="M12 6C8 3 4 4 2 5v15c4-2 7-1 10 1 3-2 6-3 10-1V5c-2-1-6-2-10 1Zm0 0v15"/>',
 sliders:'<path d="M5 3v5m0 4v9M12 3v10m0 4v4M19 3v2m0 4v12"/><path d="M2 8h6v4H2zM9 13h6v4H9zM16 5h6v4h-6z"/>',
 expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
 chevron:'<path d="m6 9 6 6 6-6"/>',
 fish:'<path d="M17 12c-6-10-13-5-15 0 2 5 9 10 15 0l5-5v10l-5-5Z"/><circle cx="6" cy="11" r=".8"/><path d="m9 6 3-3 2 5"/>',
 arrow:'<path d="M3 12h17m-6-6 6 6-6 6"/>',
 cast:'<path d="m5 21 7-14M9 14 7 13m5-6c5-10 11-3 7 1v7a3 3 0 0 1-6 0v-2l2 2"/><path d="m4 20 2 1"/>',
 reel:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="3"/><path d="m12 5 1-3m6 10h3M5 12H2m10 7v3m5-17-2 3"/>',
 hook:'<path d="M14 2v13a5 5 0 0 1-10 0v-4l3 3"/><path d="m18 5 3-2m-2 6h3"/>',
 jig:'<path d="M4 15c2-10 4 6 8-5s5 3 8-6M12 10v9m-3-3 3 3 3-3"/>',
 close:'<path d="m6 6 12 12M18 6 6 18"/>',
 eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>'
};
const svg=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name]||icons.fish}</svg>`;
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=svg(el.dataset.icon));

const touch=matchMedia('(pointer:coarse)').matches;
const canvas=$('world');
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});}catch(error){$('loading-message').textContent='WebGL 2 is needed';$('error-detail').hidden=false;$('error-detail').textContent='Please open this game in a browser with WebGL 2 enabled.';throw error;}
renderer.setPixelRatio(Math.min(devicePixelRatio,touch?1.4:1.65));
renderer.setSize(innerWidth,innerHeight);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.05;
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.xr.enabled=true;
renderer.xr.setFoveation(1);
renderer.xr.setFramebufferScaleFactor(.85);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(58,innerWidth/innerHeight,.035,2200);
camera.position.set(0,3.48,8);scene.add(camera);
let yaw=-.12,pitch=-.055,targetYaw=yaw,targetPitch=pitch;
camera.rotation.order='YXZ';camera.rotation.set(pitch,yaw,0);
const coast=createCoast(THREE,scene,{renderer});
const shoals=createShoals(THREE,scene);
const rod=createRod(THREE);camera.add(rod.group);rod.group.position.set(.5,-.58,-.56);
const sound=new CoastalAudio();
const learning=new LearningSession({onPlayback:reportWordPlayback});
let pendingVocabulary=null;
let started=false,muted=false,clean=false,quality='auto',elapsed=0,lastFrame=0,uiTime=0;
let holding=false,chargeAt=0,holdKind='',castAnim=0,jigAnim=0,catchShown=false,lastReelSpeak=-100;
let hookedFish=null,fishLength=.5,toastUntil=0,previousState='',cameraBeforeCatch={yaw,pitch};
let voiceErrorTime=-100;
const direction=new THREE.Vector3(),worldPoint=new THREE.Vector3(),projected=new THREE.Vector3();
const keys=new Set();
let journal=[];
try{const data=JSON.parse(localStorage.getItem('aonami-journal-v1')||'[]');if(Array.isArray(data))journal=data.filter(x=>SPECIES.some(s=>s.id===x.speciesId)&&Number.isFinite(x.lengthCm)&&Number.isFinite(x.weightKg)).slice(-300);}catch{}
function saveJournal(){try{localStorage.setItem('aonami-journal-v1',JSON.stringify(journal.slice(-300)));}catch{toast('Catch saved for this visit. Browser storage is unavailable.');}}
function reportWordPlayback({state,source,error}){
  const openingStatus=$('voice-test-status'),settingsStatus=$('setting-voice-status');
  const status=state==='playing'?(source==='recorded'?'Recorded voice is playing.':'Device voice is speaking.')
    :state==='finished'?'Voice sample complete.':state==='error'?`Voice could not play: ${error}`:'';
  if(openingStatus&&status)openingStatus.textContent=status;
  if(settingsStatus&&status)settingsStatus.textContent=status;
  if(state==='playing')$('action').classList.add('voice-playing');
  if(state==='finished'||state==='error')$('action').classList.remove('voice-playing');
  if(state==='error'&&elapsed-voiceErrorTime>3){
    voiceErrorTime=elapsed;
    toast('Word voice could not start. Check media volume or try Test voice in Settings.',5);
  }
}
function sayHookWord(){
  sound.start().catch(()=>{});
  const spoken=learning.speakCurrent();
  if(!spoken&&learning.muted)toast('Turn on sound to hear your new word.',2);
  else if(!spoken)toast('Speech is unavailable in this browser.',3);
  return spoken;
}
function testWordVoice(){
  if(learning.muted)learning.setMuted(false);
  sound.start().catch(()=>{});
  const sample=learning.current||learning.vocabulary.words[0];
  const status=$('voice-test-status'),settingsStatus=$('setting-voice-status');
  if(status)status.textContent='Opening pronunciation…';
  if(settingsStatus)settingsStatus.textContent='Opening pronunciation…';
  const played=learning.speakWord(sample,{repeat:false});
  if(!played){
    if(status)status.textContent='Voice is unavailable. Try opening this game in Safari.';
    if(settingsStatus)settingsStatus.textContent='No device voice or recording is available.';
  }
  const toggle=$('setting-voice');
  if(toggle){toggle.textContent='On';toggle.classList.add('on');}
}
function speakOnReel(){
  if(!shouldSpeakOnReel(engine.state,elapsed,lastReelSpeak))return;
  lastReelSpeak=elapsed;
  sayHookWord();
}

// The thin monofilament line is drawn in world space from the bending rod tip.
const linePositions=new Float32Array(73*3);
const lineGeometry=new THREE.BufferGeometry();lineGeometry.setAttribute('position',new THREE.BufferAttribute(linePositions,3));
const fishingLine=new THREE.Line(lineGeometry,new THREE.LineBasicMaterial({color:0xe9edcf,transparent:true,opacity:.83,depthWrite:false}));fishingLine.frustumCulled=false;fishingLine.renderOrder=4;scene.add(fishingLine);fishingLine.visible=false;
const floatGroup=new THREE.Group();scene.add(floatGroup);floatGroup.visible=false;
const floatWhite=new THREE.MeshStandardMaterial({color:0xf7f5de,roughness:.4});
const floatRed=new THREE.MeshStandardMaterial({color:0xe75840,roughness:.35});
const floatBody=new THREE.Mesh(new THREE.SphereGeometry(.13,16,10),floatWhite);floatBody.scale.y=1.8;floatGroup.add(floatBody);
const floatTop=new THREE.Mesh(new THREE.SphereGeometry(.131,16,10,0,Math.PI*2,0,Math.PI/2),floatRed);floatTop.scale.y=1.8;floatGroup.add(floatTop);
const floatStem=new THREE.Mesh(new THREE.CylinderGeometry(.016,.018,.32,7),new THREE.MeshStandardMaterial({color:0xf6db75,roughness:.6}));floatStem.position.y=.24;floatGroup.add(floatStem);
const jigMesh=new THREE.Mesh(new THREE.SphereGeometry(.09,10,8),new THREE.MeshStandardMaterial({color:0xd0b4b0,metalness:.7,roughness:.23}));jigMesh.scale.set(.7,.7,2.7);scene.add(jigMesh);jigMesh.visible=false;

function canvasSprite(text,{color='#fff5d6',fontSize=72,w=512,h=160}={}){const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');ctx.font=`600 ${fontSize}px Arial, sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.shadowBlur=12;ctx.shadowColor='rgba(9,49,63,.6)';ctx.fillStyle=color;ctx.fillText(text,w/2,h/2);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthTest:false,depthWrite:false}));s.scale.set(5.2,1.62,1);s.renderOrder=12;return s;}
const biteSprite=canvasSprite('ヒット！');scene.add(biteSprite);biteSprite.visible=false;
const markerCanvas=document.createElement('canvas');markerCanvas.width=128;markerCanvas.height=128;const mc=markerCanvas.getContext('2d');mc.strokeStyle='#fff8d9';mc.lineWidth=3;mc.beginPath();mc.arc(64,64,25,0,Math.PI*2);mc.stroke();mc.fillStyle='#fff8d9';mc.beginPath();mc.arc(64,64,3,0,Math.PI*2);mc.fill();
const markerTex=new THREE.CanvasTexture(markerCanvas);markerTex.colorSpace=THREE.SRGBColorSpace;const lureMarker=new THREE.Sprite(new THREE.SpriteMaterial({map:markerTex,transparent:true,opacity:.58,depthTest:false,depthWrite:false}));lureMarker.scale.set(1.6,1.6,1);lureMarker.renderOrder=6;scene.add(lureMarker);lureMarker.visible=false;
const rippleMaterial=new THREE.MeshBasicMaterial({color:0xe9ffff,transparent:true,opacity:.5,depthWrite:false,side:THREE.DoubleSide});
const rippleGeometry=new THREE.RingGeometry(.91,1,40);const ripples=[];
for(let i=0;i<6;i++){const m=new THREE.Mesh(rippleGeometry,rippleMaterial.clone());m.rotation.x=-Math.PI/2;m.visible=false;m.renderOrder=5;scene.add(m);ripples.push({m,age:100,life:1.6,base:.1});}
let rippleIndex=0,rippleClock=0;
function splash(x,z,large=false){const r=ripples[rippleIndex++%ripples.length];r.age=0;r.life=large?2:1.4;r.base=large?.25:.08;r.m.position.set(x,.08,z);r.m.visible=true;}
function clearHookedFish(){if(!hookedFish)return;scene.remove(hookedFish);hookedFish.traverse(o=>{o.geometry?.dispose();if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});hookedFish=null;}
function makeHookedFish(id,len){clearHookedFish();fishLength=Math.max(.38,len/100);hookedFish=buildFish(THREE,id,fishLength);scene.add(hookedFish);}
const engine=new FishingEngine({onEvent:onFishingEvent});

function vibrate(ms=35){try{navigator.vibrate?.(ms);}catch{}for(const c of controllers){const h=c.userData.inputSource?.gamepad?.hapticActuators?.[0];try{h?.pulse(.48,ms);}catch{}}}
function toast(message,seconds=3){$('toast').textContent=message;$('toast').classList.add('show');toastUntil=elapsed+seconds;}
function onFishingEvent(e){
  if(e.type==='cast'){sound.effect('cast');castAnim=1;catchShown=false;lastReelSpeak=-100;clearHookedFish();if(pendingVocabulary){learning.setVocabulary(pendingVocabulary);pendingVocabulary=null;}learning.nextWord();}
  if(e.type==='splash'){sound.effect('splash');splash(e.position.x,e.position.z,true);}
  if(e.type==='jig'){sound.effect('jig');jigAnim=1;}
  if(e.type==='bite'){sound.effect('bite');vibrate(100);holding=false;$('action').classList.remove('held');makeHookedFish(e.speciesId,e.lengthCm);}
  if(e.type==='hook'){sound.effect('hook');vibrate(55);sayHookWord();toast('Fish on! Listen to the word. Reel in green; release in red.',4);}
  if(e.type==='escape'){sound.effect('break');vibrate(60);toast(e.reason,4);holding=false;engine.setReeling(false);$('action').classList.remove('held');clearHookedFish();}
  if(e.type==='catch'){
    sound.effect('catch');vibrate(90);holding=false;engine.setReeling(false);$('action').classList.remove('held');
    journal.push({...e,caughtAt:new Date().toISOString()});saveJournal();
    const word=learning.catchWord(e.speciesId);
    const s=SPECIES.find(s=>s.id===e.speciesId);$('catch-name').textContent=s.en;$('catch-ja').textContent=s.ja;$('catch-length').textContent=e.lengthCm;$('catch-weight').textContent=e.weightKg.toFixed(2);$('catch-description').textContent=s.note+' Added to your journal.';
    $('catch-word').textContent=word?.word||'—';$('catch-translation').textContent=word?.translation||'—';
    $('basket-caption').textContent=`Collected ${learning.visibleBasket().length} / ${learning.vocabulary.words.length} words · Saved to basket`;
    cameraBeforeCatch={yaw:targetYaw,pitch:targetPitch};targetYaw=-.32;targetPitch=-.65;
  }
}

function start(){if(started)return;started=true;document.body.classList.add('playing');$('rotate-tip').hidden=innerWidth>innerHeight;setTimeout(()=>$('rotate-tip').hidden=true,7000);sound.start().catch(()=>{});sound.setMuted(muted);canvas.focus({preventScroll:true});}
$('start').addEventListener('click',start);
$('voice-test').addEventListener('click',testWordVoice);
$('catch-speak').addEventListener('click',sayHookWord);
function getCastDirection(){if(renderer.xr.isPresenting&&rightRay){rightRay.getWorldDirection(direction).negate();}else camera.getWorldDirection(direction);return {x:direction.x,y:direction.y,z:direction.z};}
function actionDown(){
  if(!started){start();return;}
  if(!$('modal-root').hidden)return;
  sound.start().catch(()=>{});
  if(engine.state==='bite'){engine.hook();holdKind='hook';holding=false;return;}
  if(engine.state==='caught'){continueFishing();return;}
  if(engine.state==='casting')return;
  if(holding)return;
  holding=true;chargeAt=elapsed;holdKind=engine.state==='ready'||engine.state==='escaped'?'cast':'reel';
  $('action').classList.add('held');
  if(holdKind==='reel'){engine.setReeling(true);speakOnReel();}
}
function actionUp(cancel=false){
  if(!holding){engine.setReeling(false);return;}
  holding=false;$('action').classList.remove('held');
  if(holdKind==='cast'&&!cancel){const power=clamp(.37+(elapsed-chargeAt)*.43,.37,1);engine.cast({power,direction:getCastDirection(),origin:{x:0,y:3.2,z:6}});}
  if(holdKind==='reel'&&!cancel&&engine.state==='waiting'&&engine.mode==='lure'&&elapsed-chargeAt<.23)retrieve();
  engine.setReeling(false);holdKind='';$('cast-power').style.setProperty('--power','0%');
}
let buttonPointer=null;
$('action').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();buttonPointer=e.pointerId;$('action').setPointerCapture(e.pointerId);actionDown();});
$('action').addEventListener('pointerup',e=>{e.preventDefault();if(e.pointerId===buttonPointer){actionUp();buttonPointer=null;}});
$('action').addEventListener('pointercancel',()=>{actionUp(true);buttonPointer=null;});
$('action').addEventListener('lostpointercapture',()=>{if(buttonPointer!==null){actionUp(true);buttonPointer=null;}});
// Prevent iOS text loupe, double-tap zoom and long-press callouts while
// playing. Pointer events above still drive casting, hook-set and reeling.
for(const element of [canvas,$('action'),$('hook-tap')]){
  element.addEventListener('touchstart',event=>event.preventDefault(),{passive:false});
  element.addEventListener('touchmove',event=>event.preventDefault(),{passive:false});
}
function tapFishingHook(){
  if(!started||!$('modal-root').hidden)return;
  if(engine.state==='bite')engine.hook();
  else if(engine.state==='waiting')sayHookWord();
}
function overFishingHook(clientX,clientY){
  if(engine.state!=='waiting'&&engine.state!=='bite')return false;
  const bob=engine.bobber;
  const surf=coast.waterHeight(bob.x,bob.z,elapsed);
  projected.set(bob.x,surf+.48,bob.z).project(camera);
  if(projected.z<=-1||projected.z>=1||Math.abs(projected.x)>1||Math.abs(projected.y)>1)return false;
  const x=(projected.x*.5+.5)*innerWidth,y=(-projected.y*.5+.5)*innerHeight;
  return Math.hypot(clientX-x,clientY-y)<(touch?57:41);
}
$('hook-tap').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();tapFishingHook();});
let look=null;
canvas.addEventListener('pointerdown',e=>{e.preventDefault();canvas.focus({preventScroll:true});if(!started){start();return;}if(!renderer.xr.isPresenting&&overFishingHook(e.clientX,e.clientY)){tapFishingHook();return;}if(look)return;look={id:e.pointerId,x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,moved:false,ownsAction:buttonPointer===null};canvas.setPointerCapture(e.pointerId);if(e.button===0&&look.ownsAction)actionDown();});
canvas.addEventListener('pointermove',e=>{if(!look||e.pointerId!==look.id)return;const dx=e.clientX-look.x,dy=e.clientY-look.y;if(!look.moved&&Math.hypot(e.clientX-look.sx,e.clientY-look.sy)>6){look.moved=true;if(look.ownsAction&&buttonPointer===null)actionUp(true);}if(look.moved){targetYaw=clamp(targetYaw-dx*.003,-1.1,1.1);targetPitch=clamp(targetPitch-dy*.0026,-.85,.4);}look.x=e.clientX;look.y=e.clientY;});
canvas.addEventListener('pointerup',e=>{if(!look||e.pointerId!==look.id)return;if(look.ownsAction&&buttonPointer===null)actionUp(look.moved);look=null;});
function cancelLook(){if(look?.ownsAction&&buttonPointer===null)actionUp(true);look=null;}
canvas.addEventListener('pointercancel',cancelLook);
canvas.addEventListener('lostpointercapture',cancelLook);
canvas.addEventListener('contextmenu',e=>e.preventDefault());
const editingTarget=target=>target instanceof Element&&!!target.closest('input,textarea,[contenteditable="true"]');
document.addEventListener('selectstart',e=>{if(!editingTarget(e.target))e.preventDefault();});
document.addEventListener('dragstart',e=>{if(!editingTarget(e.target))e.preventDefault();});
document.addEventListener('contextmenu',e=>{if(!editingTarget(e.target))e.preventDefault();});
document.addEventListener('dblclick',e=>{if(!editingTarget(e.target))e.preventDefault();});
for(const name of ['gesturestart','gesturechange','gestureend'])document.addEventListener(name,e=>{if(started&&!editingTarget(e.target))e.preventDefault();},{passive:false});
window.addEventListener('blur',()=>{look=null;keys.clear();actionUp(true);});
document.addEventListener('visibilitychange',()=>{lastFrame=0;keys.clear();actionUp(true);if(document.hidden)learning.stop();});
$('jig').addEventListener('click',()=>{if(engine.mode==='lure')engine.jig();else retrieve();});
$('drag').addEventListener('input',e=>engine.setDrag(+e.target.value));
function retrieve(){if(['waiting','escaped','ready'].includes(engine.state)){engine.reset();clearHookedFish();toast('Rig retrieved. Ready for another cast.',2);}}
function continueFishing(){if(engine.state!=='caught')return;$('catch-panel').hidden=true;catchShown=false;engine.release();clearHookedFish();targetYaw=cameraBeforeCatch.yaw;targetPitch=cameraBeforeCatch.pitch;}
$('continue').addEventListener('click',continueFishing);
// Ocean ambience and pronunciation are independent. Muting the ocean must
// never accidentally silence a language lesson or a REEL tap.
function toggleSound(){muted=!muted;sound.start().catch(()=>{});sound.setMuted(muted);$('sound-btn').innerHTML=svg(muted?'mute':'sound');$('sound-btn').setAttribute('aria-label',muted?'Enable ocean ambience':'Mute ocean ambience');}
$('sound-btn').addEventListener('click',toggleSound);
function toggleClean(){clean=!clean;document.body.classList.toggle('clean',clean);}
$('view-btn').addEventListener('click',toggleClean);
document.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea'))return;if(['Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();if(e.repeat)return;keys.add(e.code);if(e.code==='Escape'){closeModal();if(clean)toggleClean();}if(!$('modal-root').hidden)return;if(e.code==='Space'){actionDown();}if(e.code==='KeyJ')engine.jig();if(e.code==='KeyR')retrieve();if(e.code==='KeyM')toggleSound();if(e.code==='KeyH')toggleClean();if(e.code==='KeyP')sayHookWord();if(e.code==='Equal'||e.code==='Minus'){engine.setDrag(engine.drag+(e.code==='Equal'?.05:-.05));$('drag').value=engine.drag;}});
document.addEventListener('keyup',e=>{keys.delete(e.code);if(e.code==='Space')actionUp();});
async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else{await document.documentElement.requestFullscreen();try{await screen.orientation?.lock?.('landscape');}catch{}}}catch{toast('Rotate your phone sideways for the widest view.',3);}}
$('fullscreen-btn').addEventListener('click',fullscreen);

function openModal(title,subtitle,content){actionUp(true);$('modal-root').hidden=false;$('modal-root').innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="close" aria-label="Close">${svg('close')}</button><h2 id="modal-title">${title}</h2><p class="sub">${subtitle}</p>${content}</section></div>`;$('modal-root').querySelector('.close').onclick=closeModal;$('modal-root').querySelector('.modal-backdrop').addEventListener('click',e=>{if(e.target.classList.contains('modal-backdrop'))closeModal();});$('modal-root').querySelector('.close').focus();}
function closeModal(){$('modal-root').hidden=true;$('modal-root').innerHTML='';lastFrame=0;}
$('method').addEventListener('click',()=>{
  openModal('Find your rhythm.','Two ways to spend a little time by the water.',`<button class="method-card ${engine.mode==='lure'?'selected':''}" data-method="lure"><small>ルアー / エギング</small><strong>Lure / Eging</strong><span>Cast a sinking jig. Lift it with short taps, let it flutter, and feel for a bite. Sea bass, bream, mackerel, and squid.</span></button><button class="method-card ${engine.mode==='float'?'selected':''}" data-method="float"><small>フカセ釣り</small><strong>Float fishing</strong><span>Cast your float and watch it drift. When it dives, set the hook. A quieter way to fish the coastal shallows.</span></button><p class="panel-note">Switch methods between casts. Changing a waiting rig retrieves your line.</p>`);
  $('modal-root').querySelectorAll('[data-method]').forEach(b=>b.onclick=()=>{if(engine.setMode(b.dataset.method)){closeModal();$('method-label').textContent=engine.mode==='lure'?'Lure / Eging':'Float fishing';$('method-ja').textContent=engine.mode==='lure'?'ルアー':'フカセ';clearHookedFish();}else{toast('Finish this cast before changing your rig.',3);closeModal();}});
});
$('journal-btn').addEventListener('click',()=>showJournal('words'));

function downloadJson(filename,data){
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;link.download=filename;link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1200);
}
function showJournal(initial='words'){
  let active=initial;
  openModal('Your seaside collection.','Caught fish and learned words · 釣果と単語',
    '<div class="journal-tabs"><button class="journal-tab" id="tab-words">Words · 単語</button><button class="journal-tab" id="tab-catches">Fish · 釣果</button></div><div id="journal-content"></div>');
  const render=()=>{
    $('tab-words').classList.toggle('active',active==='words');
    $('tab-catches').classList.toggle('active',active==='catches');
    const root=$('journal-content');
    if(!root)return;
    if(active==='catches'){
      const discovered=new Set(journal.map(c=>c.speciesId));
      const largest=journal.reduce((m,c)=>Math.max(m,c.weightKg),0);
      root.innerHTML=`<div class="journal-summary"><div><strong>${journal.length}</strong><small>CATCHES</small></div><div><strong>${discovered.size} / 5</strong><small>SPECIES</small></div><div><strong>${largest.toFixed(2)}</strong><small>BEST · KG</small></div></div>${SPECIES.map(s=>{const catches=journal.filter(c=>c.speciesId===s.id);const best=Math.max(0,...catches.map(c=>c.lengthCm));return `<div class="species-row ${catches.length?'':'undiscovered'}"><div class="species-icon" style="color:${s.color}">${svg('fish')}</div><div><strong>${escapeHtml(s.en)} <small>${escapeHtml(s.ja)} · ${escapeHtml(s.habitat)}${best?' · Best '+best+' cm':''}</small></strong></div><span class="count">${catches.length||'—'}</span></div>`;}).join('')}<p class="panel-note">The journal is saved in this browser. Weights and lengths are game values.</p><div class="journal-actions"><button id="export-journal">Export catches</button></div>`;
      $('export-journal').onclick=()=>downloadJson('aonami-catches.json',{game:'Aonami',catches:journal});
    }else{
      const basket=learning.visibleBasket(),count=learning.vocabulary.words.length;
      root.innerHTML=`<div class="journal-summary"><div><strong>${basket.length}</strong><small>WORDS CAUGHT</small></div><div><strong>${count}</strong><small>IN THIS DECK</small></div><div><strong>${escapeHtml(learning.vocabulary.learningLanguage.toUpperCase())}</strong><small>LEARNING</small></div></div><p class="import-info">Tap any collected word to hear it again. Catch fish to fill your basket.</p>${basket.length?basket.slice().reverse().map((w,i)=>`<div class="vocab-row"><button data-speak-word="${basket.length-1-i}" aria-label="Speak ${escapeHtml(w.word)}">${svg('sound')}</button><div class="word-pair"><strong>${escapeHtml(w.word)}</strong><small>${escapeHtml(w.translation)}</small></div><span class="word-count">×${Number(w.catches)||1}</span></div>`).join(''):'<p class="panel-note">No words collected yet. Cast, tap your hook to hear the word, then land the fish.</p>'}<div class="journal-actions"><button class="primary" id="load-vocabulary">Import GoLingo words</button><button id="export-basket">Export basket</button><button id="clear-basket">Reset basket</button></div><p class="panel-note">Words and translations are stored on this device. Export the basket as GoLingo JSON to review it in your app.</p>`;
      root.querySelectorAll('[data-speak-word]').forEach(b=>b.onclick=()=>{sound.start().catch(()=>{});learning.speakWord(basket[+b.dataset.speakWord]);});
      $('load-vocabulary').onclick=openVocabularyModal;
      $('export-basket').onclick=()=>downloadJson('golingo-fishing-words.json',learning.exportBasket());
      $('clear-basket').onclick=e=>{
        if(e.target.dataset.armed==='yes'){learning.clearBasket();render();}
        else{e.target.dataset.armed='yes';e.target.textContent='Tap again to clear words';}
      };
    }
  };
  $('tab-words').onclick=()=>{active='words';render();};
  $('tab-catches').onclick=()=>{active='catches';render();};
  render();
}
function loadVocabulary(raw){
  const deck=parseVocabulary(raw);
  const busy=['casting','waiting','bite','fighting','caught'].includes(engine.state);
  if(busy)pendingVocabulary=deck;else learning.setVocabulary(deck);
  const label=$('lesson-ready');
  if(label){label.hidden=false;label.textContent=`GoLingo lesson: ${deck.words.length} words · ${deck.learningLanguage}${busy?' · next cast':''}`;}
  $('voice-test').textContent='🔊 Test a GoLingo word';
  return {count:deck.words.length,queued:busy,language:deck.learningLanguage};
}
function openVocabularyModal(){
  openModal('Words for the water.','Import GoLingo JSON or paste word | translation pairs.',
    '<p class="import-info">GoLingo fields: primaryLanguage, learningLanguage, words: [{id, word, translation, sentence, sentenceTranslation}]. The word plays by itself; sentences are not spoken.</p><textarea id="vocabulary-paste" class="vocabulary-editor" spellcheck="false" placeholder="海 | sea&#10;魚 | fish&#10;水 | water"></textarea><label class="import-file">Choose a JSON or text file <input id="vocabulary-file" type="file" accept=".json,.txt,application/json,text/plain"></label><p class="import-info" id="import-status" role="status">Using '+learning.vocabulary.words.length+' words. File/paste imports stay on this device.</p><label class="setting-toggle"><input id="repeat-words" type="checkbox"> Repeat the spoken word with a gentle pause</label><div class="journal-actions"><button class="primary" id="import-words">Load words</button><button id="default-words">Use Japanese sea words</button><button id="back-to-basket">Back to basket</button></div>');
  $('repeat-words').checked=learning.repeat;
  $('repeat-words').onchange=e=>learning.setRepeat(e.target.checked);
  const report=(message,error=false)=>{$('import-status').textContent=message;$('import-status').classList.toggle('status-error',error);};
  const apply=(raw)=>{
    try{const result=loadVocabulary(raw);report(`${result.count} word–translation pairs loaded${result.queued?' for your next cast':''}. Ready to fish!`);toast(`${result.count} GoLingo words ready${result.queued?' after this cast':''}.`,3);}
    catch(error){report(error.message||'Could not read these words.',true);}
  };
  $('import-words').onclick=()=>apply($('vocabulary-paste').value);
  $('vocabulary-file').onchange=async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{apply(await file.text());}catch{report('This file could not be opened.',true);}
  };
  $('default-words').onclick=()=>apply(DEFAULT_VOCABULARY);
  $('back-to-basket').onclick=()=>showJournal('words');
}
// Native GoLingo WebViews can send a full lesson via postMessage. Some shells
// send JSON text instead of an object; accept both without losing translations.
window.addEventListener('message',event=>{
  if(event.source!==window.parent&&event.source!==window)return;
  let data=event.data;
  if(typeof data==='string'){try{data=JSON.parse(data);}catch{return;}}
  if(data?.type){
    if(!['GOLINGO_WORDS','GOLINGO_GAME_DATA','GOLINGO_VOCABULARY'].includes(data.type))return;
    data=data.payload??data.data??data;
  }
  if(typeof data==='string'){try{data=JSON.parse(data);}catch{return;}}
  if(!data||(!Array.isArray(data.words)&&!Array.isArray(data)))return;
  try{const {count,queued}=loadVocabulary(data);toast(`${count} words received from GoLingo${queued?' · next cast':''}.`,3);}catch{}
});
// The gallery's actual handoff format is #data=<percent-encoded GoLingo JSON>.
// Read it before the player casts. Keep ?data= and other historical keys too.
function receiveVocabularyFromAddress(){
  const transfer=readVocabularyTransfer(location);
  if(!transfer)return;
  try{
    const {count,queued}=loadVocabulary(transfer.payload);
    if(started)toast(`${count} GoLingo words loaded${queued?' for the next cast':''}.`,3);
  }catch(error){
    const label=$('lesson-ready');
    if(label){label.hidden=false;label.textContent='Could not load the linked GoLingo lesson. Check its words and translations.';}
    toast(error.message||'Could not load the linked vocabulary.',4);
  }
}
receiveVocabularyFromAddress();
window.addEventListener('hashchange',receiveVocabularyFromAddress);
if(window.parent!==window)window.parent.postMessage({type:'GOLINGO_GAME_READY',game:'aonami-fishing'},'*');
function applyQuality(value){quality=value;const cap=value==='high'?2:value==='low'?1:touch?1.4:1.65;renderer.setPixelRatio(Math.min(devicePixelRatio,cap));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=value!=='low';}
$('settings-btn').addEventListener('click',()=>{
  openModal('Make yourself at home.','A few small things for a better day on the pier.',`<div class="setting-row"><span>Ocean sound</span><button id="setting-sound" class="switch ${muted?'':'on'}">${muted?'Off':'On'}</button></div><div class="setting-row"><span>Water & rendering</span><select id="quality" aria-label="Render quality"><option value="auto">Balanced</option><option value="high">High detail</option><option value="low">Battery saver</option></select></div><div class="setting-row"><span>Clear the view</span><button id="hide-ui" class="switch">Hide interface</button></div><dl class="controls-list"><dt>Look around</dt><dd>Drag the view / arrow keys</dd><dt>Cast</dt><dd>Hold & release CAST, click, or Space</dd><dt>Set the hook</dt><dd>Tap HOOK or press Space at ヒット！</dd><dt>Reel</dt><dd>Hold REEL, mouse, or Space</dd><dt>Let the fish run</dt><dd>Release when tension turns red</dd><dt>Jig / drag</dt><dd>J / + and −</dd><dt>Retrieve / hide UI</dt><dd>R / H</dd></dl><p class="panel-note">Quest / WebXR: right trigger casts, hooks, and reels. Left trigger also reels. Left grip jigs; right grip releases a catch. Choose your method before entering VR. VR support is experimental.</p><a class="text-link" href="./aonami-fishing.html" download="aonami-fishing.html">Download the self-contained game</a>`);
  $('quality').value=quality;$('quality').onchange=e=>applyQuality(e.target.value);$('setting-sound').onclick=e=>{toggleSound();e.target.textContent=muted?'Off':'On';e.target.classList.toggle('on',!muted);};$('hide-ui').onclick=()=>{closeModal();toggleClean();};
  $('setting-sound').closest('.setting-row').querySelector('span').textContent='Ocean ambience';
  const voiceSettings=document.createElement('div');voiceSettings.className='setting-row';
  voiceSettings.innerHTML=`<span>Word pronunciation</span><button id="setting-voice" class="switch ${learning.muted?'':'on'}">${learning.muted?'Off':'On'}</button>`;
  $('setting-sound').closest('.setting-row').after(voiceSettings);
  const testSettings=document.createElement('div');testSettings.className='voice-setting-test';
  testSettings.innerHTML='<button id="setting-test-voice" type="button">🔊 Test spoken word</button><small id="setting-voice-status" role="status" aria-live="polite">Built-in Japanese words use real recordings.</small>';
  voiceSettings.after(testSettings);
  $('setting-voice').onclick=e=>{learning.setMuted(!learning.muted);e.target.textContent=learning.muted?'Off':'On';e.target.classList.toggle('on',!learning.muted);};
  $('setting-test-voice').onclick=testWordVoice;
  const hookHelp=[...$('modal-root').querySelectorAll('.controls-list dt')].find(dt=>dt.textContent==='Set the hook');
  if(hookHelp)hookHelp.nextElementSibling.textContent='Tap the visible hook to hear; HOOK speaks on a bite';
  const reelHelp=[...$('modal-root').querySelectorAll('.controls-list dt')].find(dt=>dt.textContent==='Reel');
  if(reelHelp)reelHelp.nextElementSibling.textContent='Tap REEL to speak the word; hold to reel in';
  const learningSettings=document.createElement('div');learningSettings.className='setting-row';
  learningSettings.innerHTML='<span>Learning vocabulary</span><button id="settings-words" class="switch">Import & repeat</button>';
  $('modal-root').querySelector('.controls-list').before(learningSettings);
  $('settings-words').onclick=openVocabularyModal;
});

// Optional WebXR. Controllers share exactly the same fishing state machine.
const controllers=[],grips=[],xrRig=new THREE.Group();scene.add(xrRig);let rightRay=null,rightGrip=null;
const vrHudCanvas=document.createElement('canvas');vrHudCanvas.width=640;vrHudCanvas.height=192;const vh=vrHudCanvas.getContext('2d');const vrHudTex=new THREE.CanvasTexture(vrHudCanvas);vrHudTex.colorSpace=THREE.SRGBColorSpace;const vrHud=new THREE.Mesh(new THREE.PlaneGeometry(.58,.174),new THREE.MeshBasicMaterial({map:vrHudTex,transparent:true,depthTest:false,depthWrite:false}));vrHud.position.set(0,-.29,-.8);vrHud.renderOrder=20;vrHud.visible=false;camera.add(vrHud);
for(let i=0;i<2;i++){
 const ray=renderer.xr.getController(i),grip=renderer.xr.getControllerGrip(i);controllers.push(ray);grips.push(grip);xrRig.add(ray,grip);
 ray.addEventListener('connected',e=>{ray.userData.inputSource=e.data;if(e.data.handedness==='right'||!rightRay){rightRay=ray;rightGrip=grip;if(renderer.xr.isPresenting)attachRodToGrip();}});
 ray.addEventListener('disconnected',()=>{ray.userData.inputSource=null;if(rightRay===ray){rightRay=null;rightGrip=null;}actionUp(true);});
 ray.addEventListener('selectstart',()=>{if(ray.userData.inputSource?.handedness==='left'){if(engine.state==='fighting'){engine.setReeling(true);speakOnReel();}}else actionDown();});
 ray.addEventListener('selectend',()=>{if(ray.userData.inputSource?.handedness==='left')engine.setReeling(false);else actionUp();});
 ray.addEventListener('squeezestart',()=>{if(ray.userData.inputSource?.handedness==='left')engine.jig();else if(engine.state==='caught')continueFishing();else retrieve();});
 const handle=new THREE.Mesh(new THREE.CapsuleGeometry(.021,.065,3,7),new THREE.MeshStandardMaterial({color:0x425b56,roughness:.6}));handle.rotation.x=-.4;grip.add(handle);
}
function attachRodToGrip(){if(rightGrip){rightGrip.add(rod.group);rod.group.position.set(0,-.015,-.06);rod.group.rotation.set(0,0,0);}}
renderer.xr.addEventListener('sessionstart',()=>{start();document.body.classList.add('xr');xrRig.position.set(0,coast.pierY,8);xrRig.rotation.set(0,0,0);xrRig.add(camera);camera.position.set(0,0,0);camera.rotation.set(0,0,0);attachRodToGrip();vrHud.visible=true;renderer.shadowMap.enabled=false;});
renderer.xr.addEventListener('sessionend',()=>{document.body.classList.remove('xr');scene.add(camera);camera.position.set(0,3.48,8);camera.rotation.set(pitch,yaw,0);camera.add(rod.group);rod.group.position.set(.5,-.58,-.56);rod.group.rotation.set(0,0,0);vrHud.visible=false;renderer.shadowMap.enabled=quality!=='low';actionUp(true);lastFrame=0;});
if(navigator.xr&&isSecureContext)navigator.xr.isSessionSupported('immersive-vr').then(ok=>{$('vr-btn').hidden=!ok;}).catch(()=>{});
$('vr-btn').addEventListener('click',async()=>{try{sound.start().catch(()=>{});const session=await navigator.xr.requestSession('immersive-vr',{optionalFeatures:['local-floor','bounded-floor']});await renderer.xr.setSession(session);}catch{toast('VR could not start. Open this page directly in your Quest browser.',5);}});
function updateVrHud(){if(!renderer.xr.isPresenting)return;vh.clearRect(0,0,640,192);vh.fillStyle='rgba(244,246,230,.88)';vh.beginPath();vh.roundRect(5,5,630,180,22);vh.fill();vh.fillStyle='#214f4d';vh.textAlign='center';vh.font='27px sans-serif';vh.fillText(engine.state==='caught'?'Beautiful catch · Grip to release':engine.state==='bite'?'ヒット！ Trigger to hook & hear':engine.state==='fighting'?(engine.tension>.86?'Ease off · release the trigger':'Hold trigger to reel & hear'):engine.state==='waiting'?'Waiting for a bite · left grip to jig':'Hold & release trigger to cast',320,57);vh.font='21px sans-serif';vh.fillText(engine.state==='caught'&&learning.current?`${learning.current.word}  —  ${learning.current.translation}`:`${engine.mode==='float'?'FLOAT':'LURE'}   ${engine.distance.toFixed(1)} m   ${engine.depth.toFixed(1)} m deep`,320,101);vh.fillStyle='#c6d5c8';vh.fillRect(40,135,560,11);vh.fillStyle=engine.tension>.86?'#b95743':'#4e8a65';vh.fillRect(40,135,560*engine.tension,11);vrHudTex.needsUpdate=true;}

function updateUi(){
 const s=engine.state;
 $('depth').textContent=s==='ready'?'—':`${engine.depth.toFixed(1)} m`;
 $('distance').textContent=s==='ready'?'Ready':`${engine.distance.toFixed(0)} m`;
 $('distance-caption').textContent=s==='fighting'?'To shore / 距離':'Cast / キャスト';
 $('session-count').textContent=`${engine.sessionCatch} ${engine.sessionCatch===1?'catch':'catches'}`;
 $('fight-panel').hidden=s!=='fighting';$('center-status').hidden=s==='fighting'||s==='caught';
 $('jig').hidden=!(s==='waiting');$('jig-label').textContent=engine.mode==='lure'?'Jig · 誘う':'Retrieve · 回収';
 $('bite-notice').hidden=s!=='bite'||renderer.xr.isPresenting;
 $('reticle').hidden=s!=='ready';
 $('action').classList.toggle('biting',s==='bite');$('action').disabled=s==='casting';
 const label=s==='bite'?'HOOK':s==='fighting'?'REEL':s==='waiting'?(engine.mode==='lure'?'RETRIEVE':'WAIT'):s==='casting'?'CASTING':s==='caught'?'RELEASE':'CAST';
 if($('action-label').textContent!==label){$('action-label').textContent=label;$('action-icon').innerHTML=svg(s==='bite'?'hook':s==='fighting'||s==='waiting'?'reel':s==='caught'?'fish':'cast');}
 $('action').setAttribute('aria-label',s==='fighting'?'Hold to reel and speak the word; release to ease tension':s==='bite'?'Set the hook and speak the word':s==='caught'?'Release catch and cast again':'Hold and release to cast');
 const messages={ready:'Drag to aim. Hold and release to cast.',casting:'Your next word is on its way to the water.',waiting:engine.mode==='lure'?'Tap the hook to hear a word. JIG to lift the lure.':'Tap the float to hear a word. Wait for a bite.',bite:'ヒット！ Tap HOOK to hear the word and catch the fish!',escaped:'The next cast brings another word.',caught:''};
 $('center-status').textContent=messages[s]??'';
 $('action-title').textContent=s==='fighting'?(engine.tension>.86?'Ease off the reel':'Bring it home'):s==='waiting'?(engine.mode==='lure'?'Work the lure':'Watch the float'):s==='bite'?'Set the hook!':s==='caught'?'A lovely catch':'Find your next catch';
 $('action-sub').textContent=s==='fighting'?(engine.tension>.86?'Release to lower tension':'Hold REEL to hear word · release to rest'):s==='bite'?'Hook & hear the word':s==='waiting'?(engine.mode==='lure'?'Tap the hook to hear · J to jig':'Tap the float to hear'):'Hold, then release';
 $('tension-fill').style.width=`${engine.tension*100}%`;$('tension-fill').style.background=engine.tension>.86?'#c16049':engine.tension>.7?'#b58e43':'#558269';
 $('tension-word').textContent=engine.tension>.86?'Ease off':engine.surge>.6?'Fish pulling':engine.reeling?'Reeling':'Steady';$('fight-distance').textContent=`${engine.distance.toFixed(1)} m`;
 if(s==='caught'&&engine.stateTime>.95&&!catchShown){catchShown=true;$('catch-panel').hidden=false;}
 if(s!==previousState&&s==='bite'){$('bite-notice').classList.remove('hit-flash');void $('bite-notice').offsetWidth;$('bite-notice').classList.add('hit-flash');}
 previousState=s;updateVrHud();
}

function updateFishingVisuals(dt,t){
 const s=engine.state,active=!['ready','escaped'].includes(s);
 fishingLine.visible=active;floatGroup.visible=active&&engine.mode==='float'&&s!=='caught';jigMesh.visible=active&&engine.mode==='lure'&&s!=='caught';
 const bob=engine.bobber;const surface=coast.waterHeight(bob.x,bob.z,t);
 floatGroup.position.set(bob.x,bob.y+surface,bob.z);floatGroup.rotation.set(Math.sin(t*1.7)*.1,0,Math.cos(t*1.3)*.1);
 jigMesh.position.set(bob.x,bob.y,bob.z);jigMesh.rotation.z=Math.sin(t*2)*.3;
 const tip=rod.getTip();
 if(active){
  const end=worldPoint.set(bob.x,bob.y+(engine.mode==='float'?surface+.18:0),bob.z);const slack=s==='fighting'?.08:s==='casting'?.45:.3;
  for(let i=0;i<73;i++){const p=i/72;linePositions[i*3]=tip.x+(end.x-tip.x)*p;linePositions[i*3+1]=tip.y+(end.y-tip.y)*p-Math.sin(p*Math.PI)*slack;linePositions[i*3+2]=tip.z+(end.z-tip.z)*p;}
  lineGeometry.attributes.position.needsUpdate=true;
 }
 lureMarker.visible=s==='waiting'&&engine.mode==='lure'&&!clean;
 lureMarker.position.set(bob.x,surface+.22,bob.z);lureMarker.material.opacity=.24+Math.sin(t*2)*.05;
 const hookButton=$('hook-tap');
 if((s==='waiting'||s==='bite')&&!renderer.xr.isPresenting&&!clean){
  projected.set(bob.x,surface+.48,bob.z).project(camera);
  const visible=projected.z>-1&&projected.z<1&&Math.abs(projected.x)<.94&&Math.abs(projected.y)<.83;
  hookButton.hidden=!visible;hookButton.classList.toggle('bite-ready',s==='bite');
  if(visible){hookButton.style.left=`${(projected.x*.5+.5)*innerWidth}px`;hookButton.style.top=`${(-projected.y*.5+.5)*innerHeight}px`;}
 }else hookButton.hidden=true;
 biteSprite.visible=s==='bite'&&renderer.xr.isPresenting;biteSprite.position.set(bob.x,surface+1.5,bob.z);
 if(s==='bite'&&!renderer.xr.isPresenting){projected.set(bob.x,surface+.9,bob.z).project(camera);const sx=clamp((projected.x*.5+.5)*innerWidth,105,innerWidth-105),sy=clamp((-projected.y*.5+.5)*innerHeight,125,innerHeight-140);$('bite-notice').style.left=`${sx}px`;$('bite-notice').style.top=`${sy}px`;}
 if(hookedFish){hookedFish.position.set(engine.fishPos.x,engine.fishPos.y,engine.fishPos.z);hookedFish.rotation.y=Math.atan2(engine.fishPos.x,engine.fishPos.z-6)+Math.PI/2+Math.sin(t*4)*.15;hookedFish.rotation.z=Math.sin(t*10)*.10*(s==='caught'?.4:1);if(s==='caught'){hookedFish.rotation.y=.18;hookedFish.rotation.x=-Math.PI/2;hookedFish.position.y+=Math.abs(Math.sin(t*4))*Math.max(0,.05-engine.stateTime*.005);}hookedFish.userData.animate?.(t,s==='fighting'?.35+engine.surge*.6:s==='caught'?.16:.1);}
 rippleClock+=dt;
 if((s==='waiting'&&engine.mode==='float'||s==='bite'||s==='fighting'&&engine.depth<1)&&rippleClock>.6){splash(bob.x,bob.z,s==='bite');rippleClock=0;}
 for(const r of ripples){r.age+=dt;if(r.age>r.life){r.m.visible=false;continue;}const p=r.age/r.life;r.m.visible=true;r.m.scale.setScalar(r.base+p*(r.life===2?2.2:.75));r.m.material.opacity=(1-p)*.35;r.m.position.y=coast.waterHeight(r.m.position.x,r.m.position.z,t)+.045;}
}

let fpsTime=0,fpsFrames=0,slowCount=0;
function animate(ms){
 const dt=lastFrame?Math.min((ms-lastFrame)/1000,.05):1/60;lastFrame=ms;if(document.hidden)return;elapsed+=dt;
 const canPlay=started&&$('modal-root').hidden;
 if(canPlay)engine.update(dt,elapsed);
 castAnim=Math.max(0,castAnim-dt*2.4);jigAnim=Math.max(0,jigAnim-dt*3.5);
 if(!renderer.xr.isPresenting){
  if(canPlay){if(keys.has('ArrowLeft'))targetYaw+=dt*.6;if(keys.has('ArrowRight'))targetYaw-=dt*.6;if(keys.has('ArrowUp'))targetPitch+=dt*.4;if(keys.has('ArrowDown'))targetPitch-=dt*.4;}
  targetYaw=clamp(targetYaw,-1.1,1.1);targetPitch=clamp(targetPitch,-.85,.4);yaw=THREE.MathUtils.damp(yaw,targetYaw,11,dt);pitch=THREE.MathUtils.damp(pitch,targetPitch,11,dt);camera.rotation.set(pitch,yaw,0);
  rod.group.position.set(.5,-.58+Math.sin(elapsed*.8)*.004,-.56);rod.group.rotation.x=-Math.sin(castAnim*Math.PI)*.54-jigAnim*.16;rod.group.rotation.z=Math.sin(elapsed*.65)*.006;
 }
 rod.update(dt,elapsed,{bend:engine.rodBend,reeling:engine.reeling,struggle:engine.state==='fighting'?engine.surge:0});
 updateFishingVisuals(dt,elapsed);shoals.update(dt,elapsed);
 coast.update(dt,elapsed,camera);
 sound.update(dt,{state:engine.state,reeling:engine.reeling&&canPlay,tension:engine.tension});
 if(holding&&holdKind==='cast')$('cast-power').style.setProperty('--power',`${clamp(.37+(elapsed-chargeAt)*.43,.37,1)*100}%`);
 uiTime+=dt;if(uiTime>.08){updateUi();uiTime=0;}
 if(toastUntil&&elapsed>toastUntil){$('toast').classList.remove('show');toastUntil=0;}
 renderer.render(scene,camera);
 fpsTime+=dt;fpsFrames++;if(fpsTime>4){const fps=fpsFrames/fpsTime;if(quality==='auto'&&!renderer.xr.isPresenting&&fps<42){slowCount++;if(slowCount>=2&&renderer.getPixelRatio()>1){renderer.setPixelRatio(Math.max(1,renderer.getPixelRatio()-.2));renderer.setSize(innerWidth,innerHeight);slowCount=0;}}else slowCount=0;fpsTime=0;fpsFrames=0;}
}
window.addEventListener('resize',()=>{if(renderer.xr.isPresenting)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();renderer.setAnimationLoop(null);$('loading').style.display='flex';$('loading').style.opacity='1';$('loading-message').textContent='The graphics paused';$('error-detail').hidden=false;$('error-detail').innerHTML='Reload this page to return to the pier. Your catch journal is saved.<br><button id="reload-game" class="primary" style="margin-top:16px">Return to the coast</button>';$('reload-game').onclick=()=>location.reload();});
renderer.setAnimationLoop(animate);
requestAnimationFrame(()=>{requestAnimationFrame(()=>{$('loading').style.opacity='0';setTimeout(()=>$('loading').style.display='none',550);});});

