// GoLingo vocabulary, pronunciation and the local catch basket.
// The standalone build embeds real Japanese recordings; imported decks can
// supply audioUrl, with device text-to-speech as the general-language fallback.
export const DEFAULT_VOCABULARY = {
  primaryLanguage: 'en',
  learningLanguage: 'ja',
  words: [
    ['海','sea'],['魚','fish'],['水','water'],['船','boat'],['島','island'],
    ['波','wave'],['空','sky'],['太陽','sun'],['風','wind'],['雲','cloud'],
    ['釣り','fishing'],['釣り竿','fishing rod'],['針','hook'],['港','harbor'],
    ['灯台','lighthouse'],['砂','sand'],['岩','rock'],['鳥','bird'],
    ['泳ぐ','to swim'],['捕まえる','to catch'],['静か','quiet'],['青い','blue'],
    ['深い','deep'],['大きい','big'],['小さい','small'],['きれい','beautiful'],
    ['待つ','to wait'],['引く','to pull'],['赤い','red'],['海岸','coast'],
  ].map(([word,translation],index)=>({id:`sea-${index+1}`,word,translation}))
};

const text=(value,max)=>String(value??'').trim().slice(0,max);
const keyOf=(entry,language)=>`${language}\u0001${entry.id}\u0001${entry.word}`;
const normalizeLocale=language=>{
  const short=String(language||'ja').toLowerCase().split('-')[0];
  return ({ja:'ja-JP',en:'en-US',zh:'zh-CN',ko:'ko-KR',vi:'vi-VN',es:'es-ES',pt:'pt-BR',fr:'fr-FR',de:'de-DE',it:'it-IT',ru:'ru-RU',ar:'ar-SA',hi:'hi-IN',th:'th-TH',uk:'uk-UA'})[short]||language||'ja-JP';
};
// The GoLingo gallery navigates with #data=<encoded JSON>. URL fragments are
// not sent to GitHub Pages, so large lessons avoid the old URI-too-long error.
// Legacy game links may still send ?data=, #golingoLesson= or ?vocabulary=.
export function readVocabularyTransfer(address){
  const keys=['data','golingoLesson','golingo','vocabulary','words','lesson','golingoData'];
  const places=[['hash',String(address?.hash||'').replace(/^#/,'')],['query',String(address?.search||'')]];
  for(const [source,raw]of places){
    if(!raw)continue;
    const params=new URLSearchParams(raw);
    for(const key of keys){
      const payload=params.get(key);
      if(payload?.trim())return {payload,source,key};
    }
  }
  return null;
}
// Repeat taps while a fish fights should be audible, but never turn every
// subsecond touch event into a restart of the same speech utterance.
export const shouldSpeakOnReel=(state,time,lastSpoken)=>state==='fighting'&&time-lastSpoken>=.7;

export function parseVocabulary(raw) {
  let value=raw;
  if(typeof raw==='string'){
    const string=raw.trim();
    if(!string)throw Error('Paste some words or choose a JSON file.');
    try{value=JSON.parse(string);}catch{
      value={words:string.split(/\r?\n/).map((line,index)=>{
        const parts=line.split(/[|\t]/);
        return parts.length>1?{id:`pasted-${index+1}`,word:parts[0],translation:parts[1]}:null;
      }).filter(Boolean)};
    }
  }
  if(Array.isArray(value))value={words:value};
  if(!value||typeof value!=='object'||!Array.isArray(value.words))throw Error('Use GoLingo JSON or lines such as 海 | sea.');
  const words=[],seen=new Set();
  for(const [index,item]of value.words.slice(0,2500).entries()){
    if(!item||typeof item!=='object')continue;
    const word=text(item.word,90);
    const translation=text(item.translation??item.meaning??item.definition,180);
    if(!word||!translation)continue; // Do not silently substitute sentence translations.
    const id=text(item.id,96)||`word-${index+1}`;
    const signature=word+'\u0001'+translation;
    if(seen.has(signature))continue;
    seen.add(signature);
    const audio=item.audioUrl??item.audioURL??item.audio_url??item.pronunciationUrl??item.voiceUrl??(typeof item.audio==='string'?item.audio:item.audio?.url);
    words.push({id,word,translation,sentence:text(item.sentence,500),sentenceTranslation:text(item.sentenceTranslation,500),audioUrl:text(audio,1500)});
  }
  if(!words.length)throw Error('No usable word–translation pairs were found. Check each translation field.');
  return {primaryLanguage:text(value.primaryLanguage||'en',24),learningLanguage:text(value.learningLanguage||'ja',24),words};
}

export class LearningSession {
  constructor({storage,speech=globalThis.speechSynthesis,random=Math.random,
    audioFactory=url=>typeof Audio==='function'?new Audio(url):null,
    bundledClips=globalThis.__AONAMI_JP_AUDIO__||{},onPlayback=()=>{}}={}){
    if(storage===undefined){try{storage=globalThis.localStorage;}catch{storage=null;}}
    this.storage=storage;
    this.speech=speech;
    this.random=random;
    this.audioFactory=audioFactory;
    this.bundledClips=bundledClips;
    this.onPlayback=onPlayback;
    this.repeat=true;
    this.muted=false;
    this.current=null;
    this._speakingToken=0;
    this._timer=null;
    this._watchdog=null;
    this._activeAudio=null;
    this._activeUtterance=null;
    this.basket=[];
    this.vocabulary=parseVocabulary(DEFAULT_VOCABULARY);
    try{
      const saved=JSON.parse(storage?.getItem('aonami-vocabulary-v1')||'null');
      if(saved)this.vocabulary=parseVocabulary(saved);
    }catch{}
    try{
      const saved=JSON.parse(storage?.getItem('aonami-basket-v1')||'[]');
      if(Array.isArray(saved))this.basket=saved.filter(x=>x&&typeof x.word==='string'&&typeof x.translation==='string').slice(-3000);
    }catch{}
  }
  _persist(key,value){try{this.storage?.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
  setVocabulary(raw,{persist=true}={}){
    const parsed=parseVocabulary(raw);
    this.stop();this.vocabulary=parsed;this.current=null;
    if(persist)this._persist('aonami-vocabulary-v1',parsed);
    return parsed.words.length;
  }
  resetToDefault(){this.stop();this.vocabulary=parseVocabulary(DEFAULT_VOCABULARY);this.current=null;try{this.storage?.removeItem('aonami-vocabulary-v1');}catch{}}
  visibleBasket(){const lang=this.vocabulary.learningLanguage;const ids=new Set(this.vocabulary.words.map(w=>keyOf(w,lang)));return this.basket.filter(x=>ids.has(keyOf(x,lang)));}
  nextWord(){
    this.stop();const words=this.vocabulary.words;
    const learned=new Set(this.visibleBasket().map(w=>keyOf(w,this.vocabulary.learningLanguage)));
    let options=words.filter(w=>!learned.has(keyOf(w,this.vocabulary.learningLanguage)));
    if(!options.length)options=words;
    if(this.current&&options.length>1){const without=options.filter(x=>x.id!==this.current.id);if(without.length)options=without;}
    this.current=options[Math.min(options.length-1,Math.floor(this.random()*options.length))];
    return this.current;
  }
  catchWord(speciesId){
    const word=this.current;
    if(!word)return null;
    const key=keyOf(word,this.vocabulary.learningLanguage);
    let item=this.basket.find(x=>keyOf(x,x.learningLanguage)===key);
    if(item){item.catches=(item.catches||1)+1;item.caughtAt=new Date().toISOString();item.speciesId=speciesId;}
    else {item={...word,learningLanguage:this.vocabulary.learningLanguage,primaryLanguage:this.vocabulary.primaryLanguage,speciesId,catches:1,caughtAt:new Date().toISOString()};this.basket.push(item);}
    if(this.basket.length>3000)this.basket.splice(0,this.basket.length-3000);
    this._persist('aonami-basket-v1',this.basket);
    return word;
  }
  exportBasket(){
    const {primaryLanguage,learningLanguage}=this.vocabulary;
    return {primaryLanguage,learningLanguage,words:this.visibleBasket().map(({id,word,translation,sentence,sentenceTranslation,audioUrl})=>({id,word,translation,...(sentence?{sentence}:{}),...(sentenceTranslation?{sentenceTranslation}:{}),...(audioUrl?{audioUrl}:{})}))};
  }
  clearBasket(){const visible=new Set(this.visibleBasket().map(x=>keyOf(x,x.learningLanguage)));this.basket=this.basket.filter(x=>!visible.has(keyOf(x,x.learningLanguage)));this._persist('aonami-basket-v1',this.basket);}
  stop(){
    this._speakingToken++;
    if(this._timer!==null)clearTimeout(this._timer);
    this._timer=null;
    if(this._watchdog!==null)clearTimeout(this._watchdog);
    this._watchdog=null;
    if(this._activeAudio){
      const player=this._activeAudio;
      player.onplaying=null;player.onended=null;player.onerror=null;
      try{player.pause();}catch{}
      this._activeAudio=null;
    }
    if(this._activeUtterance){try{this.speech?.cancel();}catch{}}
    this._activeUtterance=null;
  }
  _report(state,source,word,error=''){
    try{this.onPlayback({state,source,word:word?.word||'',error});}catch{}
  }
  speakCurrent(){
    return this.speakWord(this.current,{repeat:this.repeat});
  }
  speakWord(word,{repeat=false}={}){
    if(!word||this.muted){this._report('unavailable','none',word,'Voice is muted or no word is selected.');return false;}
    this.stop();
    const token=this._speakingToken;
    const locale=normalizeLocale(this.vocabulary.learningLanguage);
    const url=word.audioUrl||(locale.startsWith('ja')?this.bundledClips[word.word]:null);
    if(url&&this._playClip(token,word,repeat,url))return true;
    return this._speak(token,word,repeat);
  }
  _playClip(token,word,repeat,url){
    let player;
    try{player=this.audioFactory(url);}catch{return false;}
    if(!player||typeof player.play!=='function')return false;
    this._activeAudio=player;
    player.preload='auto';
    player.loop=!!repeat&&this.repeat;
    player.volume=1;
    player.onplaying=()=>{if(token===this._speakingToken)this._report('playing','recorded',word);};
    const fallback=error=>{
      if(token!==this._speakingToken||this._activeAudio!==player)return;
      player.onplaying=null;player.onended=null;player.onerror=null;
      try{player.pause();}catch{}
      this._activeAudio=null;
      if(!this._speak(token,word,repeat))this._report('error','recorded',word,String(error?.message||error||'Audio could not start.'));
    };
    player.onerror=()=>fallback(player.error?.message||'Audio could not be decoded.');
    player.onended=()=>{if(token===this._speakingToken)this._report('finished','recorded',word);};
    try{
      // Crucially, play() runs *synchronously inside the REEL / hook gesture*.
      // An actual MP3 works even if iOS WebKit has no speech-synthesis voice.
      const started=player.play();
      if(started&&typeof started.catch==='function')started.catch(fallback);
      return true;
    }catch(error){fallback(error);return true;}
  }
  _speak(token,word,repeat){
    if(token!==this._speakingToken||this.muted||!word||!this.speech||typeof SpeechSynthesisUtterance==='undefined')return false;
    try{
      const utterance=new SpeechSynthesisUtterance(word.word);
      // Keep a strong reference to the utterance: iOS WebKit can otherwise
      // collect it before onstart/onend and silently drop the speech request.
      this._activeUtterance=utterance;
      utterance.lang=normalizeLocale(this.vocabulary.learningLanguage);
      utterance.rate=.85;utterance.pitch=1.03;utterance.volume=.95;
      const voices=this.speech.getVoices?.()||[];
      const exact=voices.find(v=>(v.lang||'').toLowerCase()===utterance.lang.toLowerCase());
      const approximate=voices.find(v=>(v.lang||'').toLowerCase().startsWith(utterance.lang.slice(0,2).toLowerCase()));
      if(exact||approximate)utterance.voice=exact||approximate;
      utterance.onstart=()=>{
        if(token!==this._speakingToken)return;
        if(this._watchdog!==null)clearTimeout(this._watchdog);
        this._watchdog=null;
        this._report('playing','device',word);
      };
      utterance.onend=()=>{
        if(token!==this._speakingToken)return;
        this._activeUtterance=null;
        this._report('finished','device',word);
        if(repeat&&this.repeat&&!this.muted&&token===this._speakingToken){
          this._timer=setTimeout(()=>this._speak(token,word,repeat),1650);
        }
      };
      utterance.onerror=event=>{
        if(token!==this._speakingToken)return;
        this._activeUtterance=null;
        if(this._watchdog!==null)clearTimeout(this._watchdog);
        this._watchdog=null;
        this._report('error','device',word,event.error||'The device speech engine could not start.');
      };
      this._watchdog=setTimeout(()=>{
        if(token!==this._speakingToken||this._activeUtterance!==utterance)return;
        this._watchdog=null;
        if(!this.speech?.speaking)this._report('error','device',word,'No speech started. Check the device voice settings.');
      },4000);
      this.speech.resume?.();this.speech.speak(utterance);
      return true;
    }catch(error){this._activeUtterance=null;this._report('error','device',word,String(error));return false;}
  }
  setMuted(muted){this.muted=!!muted;if(muted)this.stop();}
  setRepeat(repeat){this.repeat=!!repeat;if(this._activeAudio)this._activeAudio.loop=this.repeat;if(!repeat&&this._timer!==null){clearTimeout(this._timer);this._timer=null;}}
}
