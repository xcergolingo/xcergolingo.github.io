// Procedural coastal fish. Catch ranges are tuned for this game's fishing grounds.
export const SPECIES = [
  { id: 'madai', en: 'Red sea bream', ja: 'マダイ', color: '#d88581', length: [24, 68], weight: [.35, 4.8], depth: [3, 16], habitat: 'Rocky ground · 岩礁', rarity: 'Uncommon', note: 'A rose-gold fish with a deep body and a powerful first run.' },
  { id: 'aji', en: 'Horse mackerel', ja: 'マアジ', color: '#99b6a8', length: [16, 38], weight: [.07, .65], depth: [1, 8], habitat: 'Harbor schools · 沿岸', rarity: 'Common', note: 'A quick silver schooling fish. A good first catch.' },
  { id: 'suzuki', en: 'Japanese sea bass', ja: 'スズキ', color: '#90aaa8', length: [38, 92], weight: [.55, 7.2], depth: [2, 12], habitat: 'Coastal shallows · 浅瀬', rarity: 'Rare', note: 'A long silver predator that makes determined runs for open water.' },
  { id: 'saba', en: 'Chub mackerel', ja: 'マサバ', color: '#76a8bd', length: [22, 48], weight: [.16, 1.35], depth: [1, 10], habitat: 'Open-water schools · 回遊', rarity: 'Common', note: 'Blue-green markings and a fast, restless swimming action.' },
  { id: 'aori', en: 'Bigfin reef squid', ja: 'アオリイカ', color: '#d4bca0', length: [15, 42], weight: [.2, 2.8], depth: [2, 9], habitat: 'Rock & seagrass · 藻場', rarity: 'Uncommon', note: 'Broad ribbon-like fins. Try the eging jig to tempt one.' }
];

const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

function geometryFromArrays(THREE, positions, indices, colors, uvs) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  if (colors) geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  if (uvs) geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

let scaleNormalTexture;
function getScaleNormals(THREE){
  if(scaleNormalTexture)return scaleNormalTexture;
  const width=128,height=128,heights=new Float32Array(width*height);
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const ctx=canvas.getContext('2d'),image=ctx.createImageData(width,height);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const row=Math.floor(y/16),u=((x+(row%2)*10)%20)/20-.5,v=(y%16)/16;
    // Overlapping, staggered scales, with a faint raised lip at each edge.
    const scale=Math.max(0,Math.cos(u*Math.PI))*Math.sin(v*Math.PI);
    const lip=Math.exp(-Math.pow((v-.79)*10,2))*.17*Math.cos(u*Math.PI);
    heights[y*width+x]=scale*.22+lip;
  }
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const i=(y*width+x)*4;
    let nx=(heights[y*width+(x+width-1)%width]-heights[y*width+(x+1)%width])*1.8;
    let ny=(heights[((y+height-1)%height)*width+x]-heights[((y+1)%height)*width+x])*1.8;
    let nz=1;const inv=1/Math.hypot(nx,ny,nz);nx*=inv;ny*=inv;nz*=inv;
    image.data[i]=Math.round((nx*.5+.5)*255);image.data[i+1]=Math.round((ny*.5+.5)*255);image.data[i+2]=Math.round((nz*.5+.5)*255);image.data[i+3]=255;
  }
  ctx.putImageData(image,0,0);
  scaleNormalTexture=new THREE.CanvasTexture(canvas);
  scaleNormalTexture.wrapS=scaleNormalTexture.wrapT=THREE.RepeatWrapping;
  scaleNormalTexture.repeat.set(4,2);
  scaleNormalTexture.anisotropy=4;
  return scaleNormalTexture;
}

function fishBody(THREE, id, simple = false) {
  const deep = id === 'madai';
  const bass = id === 'suzuki';
  const sections = simple ? 19 : 39;
  const around = simple ? 14 : 26;
  const positions = [], indices = [], colors = [], uvs=[];
  const top = new THREE.Color(deep ? '#9d4c50' : id === 'saba' ? '#325568' : bass ? '#5e7375' : '#5a7770');
  const middle = new THREE.Color(deep ? '#e9a4a0' : id === 'saba' ? '#b2ccca' : '#c6d4c9');
  const belly = new THREE.Color(deep ? '#ffe1ca' : '#edf0dc');
  const c = new THREE.Color();
  for (let i = 0; i <= sections; i++) {
    const u = i / sections;
    const x = -.405 + u * .86;
    // The tail wrist is slim, shoulder rounded, forehead and snout are asymmetric.
    const profile = Math.pow(Math.sin(Math.PI * clamp(u * .94 + .025, .02, .995)), .83);
    const shoulder = .76 + .24 * Math.exp(-Math.pow((u - .66) * 3, 2));
    const height = (deep ? .235 : bass ? .157 : .165) * profile * shoulder;
    const width = (deep ? .077 : bass ? .083 : .067) * profile;
    const centerY = .012 * Math.sin(u * Math.PI) + (deep ? .018 : 0);
    for (let j = 0; j <= around; j++) {
      const theta = j / around * Math.PI * 2;
      const sy = Math.cos(theta), sz = Math.sin(theta);
      let py = sy * height;
      if (sy > 0 && u > .72) py *= 1 - (u - .72) * 1.5;
      positions.push(x, centerY + py, sz * width);
      uvs.push(u,j/around);
      if (sy > .25) c.copy(middle).lerp(top, (sy - .25) / .75);
      else c.copy(middle).lerp(belly, clamp((.25 - sy) / 1.25, 0, 1));
      const scale = .94 + .06 * Math.sin(i * 2.399 + j * 1.7);
      c.multiplyScalar(scale);
      if (id === 'saba' && sy > .12 && Math.sin(u * 59 + Math.sin(theta * 3) * 3.5) > .43) c.multiplyScalar(.60);
      if (deep && sy > -.1 && Math.sin(i * 2.7 + j * 7.3) > .94) c.lerp(new THREE.Color('#91cee5'), .65);
      if (id === 'aji' && Math.abs(sy + .02) < .11) c.lerp(new THREE.Color('#adad75'), .45);
      colors.push(c.r, c.g, c.b);
      if (i < sections && j < around) {
        const a = i * (around + 1) + j, b = a + around + 1;
        indices.push(a, a + 1, b, b, a + 1, b + 1);
      }
    }
  }
  return geometryFromArrays(THREE, positions, indices, colors, uvs);
}

function finSurface(THREE, pts, color, opacity = .76) {
  const positions = pts.flat(), indices = [];
  for (let i = 1; i < pts.length - 1; i++) indices.push(0, i, i + 1);
  const geometry = geometryFromArrays(THREE, positions, indices);
  return new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color, transparent: true, opacity, roughness: .42, metalness: .18, side: THREE.DoubleSide, depthWrite: false }));
}

function tube(THREE, pts, radius, material) {
  return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p))), Math.max(5, pts.length * 3), radius, 5, false), material);
}

function eye(THREE, group, x, y, z, radius, simple) {
  const gold = new THREE.MeshStandardMaterial({ color: '#a2a583', roughness: .28, metalness: .5 });
  const iris = new THREE.Mesh(new THREE.SphereGeometry(radius, simple ? 8 : 14, simple ? 6 : 10), gold);
  iris.position.set(x, y, z);
  iris.scale.z = .40;
  group.add(iris);
  const pupil = new THREE.Mesh(new THREE.SphereGeometry(radius * .63, 12, 8), new THREE.MeshStandardMaterial({ color: '#081518', roughness: .09, metalness: .25 }));
  pupil.position.set(x + .001, y, z + Math.sign(z) * radius * .32);
  pupil.scale.z = .40;
  group.add(pupil);
  if (!simple) {
    const glint = new THREE.Mesh(new THREE.SphereGeometry(radius * .18, 6, 4), new THREE.MeshBasicMaterial({ color: '#fffdf1' }));
    glint.position.set(x + radius * .22, y + radius * .28, z + Math.sign(z) * radius * .57);
    group.add(glint);
  }
}

function buildSquid(THREE, size, simple) {
  const group = new THREE.Group();
  const positions = [], colors = [], indices = [];
  const count = simple ? 16 : 34, radial = simple ? 12 : 22;
  const light = new THREE.Color('#eadbbd'), brown = new THREE.Color('#a68d68');
  for (let i = 0; i <= count; i++) {
    const u = i / count, radius = .125 * Math.pow(Math.sin(Math.PI * u * .76), .67);
    for (let j = 0; j <= radial; j++) {
      const a = j / radial * Math.PI * 2;
      positions.push(-.48 + u * .60, Math.cos(a) * radius * .85, Math.sin(a) * radius);
      const tint = light.clone().lerp(brown, .17 + .30 * Math.max(0, Math.cos(a)) + (Math.sin(i * 7.3 + j * 5.1) > .75 ? .26 : 0));
      colors.push(tint.r, tint.g, tint.b);
      if (i < count && j < radial) {
        const k = i * (radial + 1) + j, next = k + radial + 1;
        indices.push(k, k + 1, next, next, k + 1, next + 1);
      }
    }
  }
  const skin = new THREE.MeshStandardMaterial({ color: '#eee4ca', roughness: .32, metalness: .23, vertexColors: true });
  group.add(new THREE.Mesh(geometryFromArrays(THREE, positions, indices, colors), skin));
  const fins = [];
  for (const s of [-1, 1]) {
    const fin = finSurface(THREE, [[-.46, 0, 0], [-.32, .008, s * .15], [-.13, 0, s * .24], [.11, -.005, s * .16], [.13, 0, s * .08], [-.18, 0, s * .06]], '#dbcaa2', .68);
    fins.push(fin); group.add(fin);
  }
  const head = new THREE.Mesh(new THREE.SphereGeometry(.075, 14, 12), new THREE.MeshStandardMaterial({ color: '#cbb99a', roughness: .35, metalness: .18 }));
  head.scale.set(1.05, .88, 1.07); head.position.set(.15, -.005, 0); group.add(head);
  eye(THREE, group, .155, .012, .069, .029, simple);
  eye(THREE, group, .155, .012, -.069, .029, simple);
  const arms = new THREE.Group();
  arms.position.x = .20;
  const armMat = new THREE.MeshStandardMaterial({ color: '#d9cbb3', roughness: .42, metalness: .12 });
  for (let i = 0; i < (simple ? 6 : 8); i++) {
    const a = i / 8 * Math.PI * 2;
    const dy = Math.cos(a), dz = Math.sin(a);
    const len = i === 2 || i === 6 ? .36 : .25;
    arms.add(tube(THREE, [[0, dy * .025, dz * .025], [.12, dy * .06, dz * .065], [len * .78, dy * .055 - .012, dz * .075], [len, dy * .012 - .018, dz * .09]], .011, armMat));
  }
  group.add(arms);
  group.scale.setScalar(size);
  group.userData.animate = (time, struggle = 0) => {
    fins.forEach((f, i) => { f.rotation.x = Math.sin(time * (4 + struggle * 7) + i) * (.10 + struggle * .14); });
    arms.rotation.y = Math.sin(time * (3 + struggle * 8)) * (.05 + struggle * .20);
    arms.rotation.z = Math.cos(time * 4) * .035;
  };
  group.userData.speciesId = 'aori';
  return group;
}

export function buildFish(THREE, speciesId = 'madai', size = 1, options = {}) {
  const simple = !!options.simple;
  const species = SPECIES.find(s => s.id === speciesId) || SPECIES[0];
  if (species.id === 'aori') return buildSquid(THREE, size, simple);
  const group = new THREE.Group(), deep = species.id === 'madai';
  const material = simple
    ? new THREE.MeshStandardMaterial({vertexColors:true,roughness:.36,metalness:.28})
    : new THREE.MeshPhysicalMaterial({vertexColors:true,roughness:.27,metalness:.20,clearcoat:.66,clearcoatRoughness:.19,normalMap:getScaleNormals(THREE),normalScale:new THREE.Vector2(.19,.19)});
  const body = new THREE.Mesh(fishBody(THREE, species.id, simple), material);
  group.add(body);
  const finColor = deep ? '#bd7069' : species.id === 'saba' ? '#65858b' : '#899b89';
  const tail = new THREE.Group(); tail.position.set(-.39, .012, 0);
  tail.add(finSurface(THREE, [[.04, 0, 0], [-.07, .066, 0], [-.24, .19, 0], [-.19, .052, 0], [-.135, 0, 0], [-.19, -.052, 0], [-.24, -.18, 0], [-.07, -.061, 0]], finColor, .9));
  group.add(tail);
  const top = deep ? .21 : .15;
  const dorsalPoints = [[-.30, top * .48, 0], [-.23, top * .88, 0], [-.19, top + .085, 0], [-.145, top + .04, 0], [-.11, top + .12, 0], [-.065, top + .06, 0], [-.025, top + .13, 0], [.02, top + .07, 0], [.06, top + .10, 0], [.13, top + .05, 0], [.24, top * .72, 0], [.13, top * .79, 0]];
  const dorsal = finSurface(THREE, dorsalPoints, finColor, .72); group.add(dorsal);
  const bottom = deep ? -.19 : -.13;
  group.add(finSurface(THREE, [[-.27, bottom * .48, 0], [-.17, bottom - .075, 0], [.06, bottom - .02, 0], [.15, bottom * .74, 0]], finColor, .68));
  const pectorals = [];
  for (const s of [-1, 1]) {
    const fin = finSurface(THREE, [[.13, -.005, s * .066], [-.12, -.14, s * .17], [-.03, -.035, s * .082]], deep ? '#d99b87' : '#bdc5ad', .65);
    pectorals.push(fin); group.add(fin);
  }
  let mouth, lip;
  if (!simple) {
    eye(THREE, group, .335, .060, .053, .030, false);
    eye(THREE, group, .335, .060, -.053, .030, false);
    const gillMat = new THREE.MeshStandardMaterial({ color: deep ? '#a36062' : '#7a9089', roughness: .4, metalness: .3 });
    for (const s of [-1, 1]) {
      group.add(tube(THREE, [[.24, .11, s * .056], [.20, .055, s * .075], [.19, -.035, s * .072], [.25, -.09, s * .055]], .0026, gillMat));
      group.add(tube(THREE, [[-.29, .025, s * .04], [-.11, .025, s * .073], [.09, .035, s * .075], [.2, .025, s * .065]], .0015, gillMat));
    }
    mouth = new THREE.Mesh(new THREE.CircleGeometry(.035, 16), new THREE.MeshBasicMaterial({ color: '#403135', side: THREE.DoubleSide }));
    mouth.rotation.y = Math.PI / 2; mouth.position.set(.456, -.009, 0); mouth.scale.y = .22; group.add(mouth);
    lip = new THREE.Mesh(new THREE.TorusGeometry(.034, .004, 5, 16), new THREE.MeshStandardMaterial({ color: deep ? '#d49e8e' : '#afbab0', roughness: .35, metalness: .3 }));
    lip.rotation.y = Math.PI / 2; lip.position.copy(mouth.position); lip.scale.y = .28; group.add(lip);
  }
  group.scale.setScalar(size);
  group.userData.speciesId = species.id;
  group.userData.animate = (time, struggle = 0) => {
    const speed = 5 + struggle * 11;
    tail.rotation.y = Math.sin(time * speed) * (.23 + struggle * .38);
    pectorals.forEach((f, i) => { f.rotation.x = Math.sin(time * 3.7 + i * 2) * (.07 + struggle * .1); });
    dorsal.rotation.x = Math.sin(time * speed * .65) * (.035 + struggle * .065);
    if (mouth) {
      const open = .22 + struggle * .78 + Math.sin(time * 2) * .055;
      mouth.scale.y = open;
      lip.scale.y = open + .04;
    }
  };
  return group;
}

export function createShoals(THREE, scene) {
  const group = new THREE.Group(); group.name = 'coastal-shoals'; scene.add(group);
  const members = [];
  const schools = [
    { id: 'aji', x: -8, z: -12, y: -1.4, r: 5, n: 5, speed: .18, size: .43 },
    { id: 'saba', x: 9, z: -25, y: -2.8, r: 8, n: 4, speed: -.14, size: .62 },
    { id: 'madai', x: -15, z: -31, y: -3.5, r: 7, n: 3, speed: .09, size: .80 },
    { id: 'suzuki', x: 16, z: -16, y: -2.1, r: 6, n: 2, speed: -.11, size: 1.04 }
  ];
  for (const school of schools) {
    for (let i = 0; i < school.n; i++) {
      const fish = buildFish(THREE, school.id, school.size * (.86 + i * .06), { simple: true });
      fish.traverse(obj => { if (obj.isMesh) { obj.castShadow = false; obj.receiveShadow = false; } });
      group.add(fish); members.push({ fish, school, phase: i * .31, row: i % 2 });
    }
  }
  return {
    group,
    update(dt, time) {
      for (const member of members) {
        const { fish, school, phase, row } = member;
        const t = time * school.speed + phase;
        const x = school.x + Math.cos(t) * (school.r + row * .6);
        const z = school.z + Math.sin(t) * school.r * .48;
        fish.position.set(x, school.y + Math.sin(time * .47 + phase * 3) * .15 - row * .25, z);
        const dx = -Math.sin(t) * school.speed, dz = Math.cos(t) * school.speed * .48;
        fish.rotation.y = -Math.atan2(dz, dx);
        fish.userData.animate(time + phase * 6, 0);
      }
    },
    dispose() {
      scene.remove(group);
      group.traverse(obj => { if (obj.isMesh) { obj.geometry.dispose(); const mats = Array.isArray(obj.material) ? obj.material : [obj.material]; mats.forEach(m => m.dispose()); } });
    }
  };
}
