# Aonami — Coastal Fishing

A first-person coastal fishing game made with **Three.js 0.180.0**. Fish from a wooden pier beside a red lighthouse and stone breakwater, with animated turquoise water, distant islands, seabirds, and procedural coastal sound.

The current scenery uses a densely sampled water mesh near the pier, **five animated wave layers**, two independently drifting normal textures for capillary ripples, sun glints, cloud-shadow colour variation, planar lighthouse reflections, and shoreline foam. A physically modeled Three.js daylight sky adds atmospheric sun scattering behind the procedural clouds. Distant mountains use multi-scale eroded ridgelines and slope-dependent exposed rock, instead of repeating sine-wave hills. The pier, stones, and lighthouse paint have generated surface textures with fine normal detail. The red lighthouse has small service windows, expansion bands and metal fasteners that catch the light. A prefiltered sea-and-sky environment adds reflections to wet fish skin and metal hardware. Island ridges contain distant tree cover, and a small fishing boat rests offshore. The working pier has tackle, a cooler, a safety ring, barnacles, tidal wood staining and animated ripples around its pilings. The breakwater has an algae-stained waterline and irregular foam, while rocks are scattered along the sandy underwater bottom. All assets remain generated or bundled inside the standalone HTML build.

## GoLingo word fishing

The game now doubles as a Japanese-to-English language-learning experience, with 30 coastal words installed by default. Each cast assigns one word to the fishing hook. **Tap the small speaker icon above the lure or float** to hear the word (with no vocabulary card blocking the ocean). When **ヒット！** appears, tapping **HOOK** sets the hook and speaks the same word. **Tap or hold REEL while fighting to speak the word again** while drawing in the fish. Repeated reel touches are debounced so they do not interrupt the same pronunciation too rapidly. Spoken words repeat with a quiet pause until the next word, unless the repeat setting is disabled. Only the word is spoken, not the example sentence.

Land the fish to reveal the **word and its translation** in the catch result. The word is also saved in a local **learning basket**. Open the book icon to switch between the word basket and fish journal. You can hear collected words again and **export the basket as GoLingo-compatible JSON**. The catch result is the only point where the large word and translation appear, so the scene stays visible while fishing.

To use your own words, open the **book icon → Import GoLingo words**. Paste `word | translation` lines, paste GoLingo JSON, or choose a `.json`/`.txt` file. The preferred schema is:

```json
{
  "primaryLanguage": "en",
  "learningLanguage": "ja",
  "words": [
    { "id": "101", "word": "水", "translation": "water", "sentence": "水を飲みます。", "sentenceTranslation": "I drink water." },
    { "id": "102", "word": "船", "translation": "boat", "sentence": "船に乗ります。", "sentenceTranslation": "I ride the boat." }
  ]
}
```

For embedding in GoLingo or a website, the parent page can send the same object through `iframe.contentWindow.postMessage({type:'GOLINGO_WORDS',payload:wordData},'*')`. This supports much larger sets than a query string; small legacy `?data=` JSON values also work. The game announces readiness to its parent with `GOLINGO_GAME_READY`. Replacing a deck during an active cast queues the replacement for the next cast.

**The 30 built-in Japanese words now have real recorded audio embedded directly in the HTML.** Tapping HOOK, the floating speaker, or REEL starts a recording from the user gesture, without relying on iPhone speech synthesis. The clips include a quiet pause so their optional continuous repeat is not rushed. Imported GoLingo entries can include `audioUrl`; if a word has no recorded clip, the game falls back to a matching browser/device speech-synthesis voice and reports errors instead of silently claiming success. Device TTS results vary by browser and installed voices.

Tap **🔊 Test Japanese voice** on the opening screen, or **Settings → Test spoken word**, to check audio immediately. The top-right sound toggle controls **ocean ambience only**; it cannot inadvertently mute word lessons. Settings has a separate Word pronunciation On/Off switch. If even the test recording is silent, check iPhone media volume and output device (including Bluetooth), and try opening the link in Safari rather than a restricted in-app browser. Game controls prevent iOS text callouts, text selection and double-tap zoom when holding REEL; the importer still allows normal paste and editing. Vocabulary and collected words are saved in this browser only, not automatically sent to GoLingo servers.

## Play

Open **`dist/aonami-fishing.html`** in a modern browser, then start the game to enable sound. This is the complete, bundled HTML edition: Three.js, game code, styling, models, textures, and audio generation are included, with no runtime CDN or asset downloads. `dist/index.html` is the hosting entry point.

Desktop and touch controls are supported. Landscape gives phones the widest view. Use the fullscreen button when supported by your browser.

## Controls

| Action | Desktop | Touch |
| --- | --- | --- |
| Look around | Drag the scene or use arrow keys | Drag the scene |
| Cast | Hold the Cast button, left mouse button, or Space; release to cast | Hold Cast, then release |
| Set the hook | Click the Bite action or press Space when **ヒット！** appears | Tap the Bite action |
| Hear the current word | Click the hook's speaker icon or press P; the Hook action also speaks on a bite | Tap the speaker icon on the float/lure or tap HOOK on a bite |
| Reel during a fight and hear the word | Press or hold Reel, left mouse button, or Space | Tap or hold Reel; each new press speaks the word |
| Ease line tension | Release the reel control | Release Reel |
| Jig the lure | Press J or use the jig button | Tap the jig button |
| Adjust drag | Use + / − or the drag control | Use the drag control |
| Retrieve or reset | Press R while waiting or after an escape | Use the on-screen retrieve action |
| Hide or show interface | Press H | Use the interface toggle |
| Toggle ocean ambience | Press M | Use the sound button (word voice stays on) |
| Check voice | Open the game and select Test Japanese voice, or use Settings | Tap Test Japanese voice before starting |

### Fishing loop

1. Choose a rig, aim toward open water, and cast.
2. Watch the float or work the lure. A bite appears after a short delay.
3. Set the hook while **ヒット！ / Bite!** is visible.
4. Reel while tension is green. **Release when it turns red**, let the fish's pull ease, and resume reeling. Lower drag makes the line easier to manage; higher drag brings the fish in faster but increases tension.
5. Land the fish on the pier, see its length and weight, and release it to cast again.

Holding the reel continuously through a strong pull can snap the line. Leaving very loose drag slack for too long can let the hook slip. Missed bites and escaped fish reset for another cast.

## Two fishing styles

- **Lure / Eging:** The jig sinks below the surface. Use short jig actions to lift it and attract fish, then let it flutter down.
- **Float / フカセ:** Watch the surface float for a bite and set the hook when it dips.

The catch collection includes Japanese coastal fish such as sea bream (**マダイ**), horse mackerel (**マアジ**), Japanese sea bass (**スズキ**), chub mackerel (**マサバ**), and bigfin reef squid (**アオリイカ**). The journal is stored in this browser's `localStorage`; it does not sync between devices and may be cleared with browser data.

Species sizes, weights, behavior, and rig selection are **gameplay values**, not a biological or fishing reference.

## Experimental WebXR

WebXR requires a compatible browser, headset, and a secure origin such as HTTPS or localhost. Controller support is experimental and **has not been verified on a physical headset**.

- **Trigger:** charge/release a cast, set the hook on a bite, and hold to reel during a fight.
- **Left squeeze:** jig the lure.
- **Right squeeze:** release a caught fish.

Regular desktop and touch play do not require WebXR.

## Source and build

The project uses plain JavaScript and Three.js, with no UI framework. Scenery, models and ocean effects are generated by the application. The 30 small AI-generated Japanese pronunciation recordings are stored under `assets/voice/` and embedded into the single-file HTML by `build.mjs`, so the built game needs no external audio service or CDN for its default Japanese vocabulary.

```sh
npm install
npm run build
npm test
```

The build bundles the game and Three.js into the HTML files under `dist/`. Serve that directory with any static web server, or open the standalone HTML for local desktop play.

| Location | Purpose |
| --- | --- |
| `src/` | Scene, simulation, fish models, audio, and game interface source |
| `src/coast.js` | Ocean, pier, lighthouse, breakwater, landscape, and birds |
| `src/fishing.js` | Renderer-independent casting, bites, fish fights, and catch state |
| `src/fish.js` | Procedural species models and swimming fish |
| `src/audio.js` | Procedural ocean ambience and fishing sound effects |
| `assets/voice/` | 30 Japanese spoken-word MP3 clips, numbered in default vocabulary order |
| `src/learning.js` | GoLingo data imports, pronunciation, repeated word audio, and word-basket persistence |
| `tests/` | Renderer-independent tests for vocabulary, fishing loop, and procedural scene geometry |
| `build.mjs` | Produces the bundled HTML distribution |
| `dist/aonami-fishing.html` | Complete standalone game |
| `dist/index.html` | Static hosting entry point |

Performance depends on the device, browser, screen resolution, and headset. Desktop and VR frame-rate targets are goals rather than guaranteed measurements.
