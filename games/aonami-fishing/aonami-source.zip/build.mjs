import { build } from 'esbuild';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { DEFAULT_VOCABULARY } from './src/learning.js';
const result=await build({entryPoints:['src/main.js'],bundle:true,format:'iife',target:'es2020',minify:true,legalComments:'inline',write:false});
const license=await readFile('node_modules/three/LICENSE','utf8');
// Each default Japanese word has a real, locally bundled recording. Inline the
// MP3 clips so the downloadable HTML works without internet or device TTS.
const recordings=await Promise.all(DEFAULT_VOCABULARY.words.map(async(entry,index)=>[
  entry.word,'data:audio/mpeg;base64,'+(await readFile(`assets/voice/${String(index+1).padStart(2,'0')}.mp3`)).toString('base64')
]));
const html=(await readFile('src/template.html','utf8'))
  .replace('<head>','<head>\n<!-- Three.js license\n'+license.replace(/-->/g,'-- >')+'\n-->')
  .replace('/*__STYLE__*/',await readFile('src/style.css','utf8'))
  .replace('/*__VOICE__*/',()=>`globalThis.__AONAMI_JP_AUDIO__=${JSON.stringify(Object.fromEntries(recordings))};`)
  .replace('/*__GAME__*/',()=>result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script'));
await mkdir('dist',{recursive:true});await writeFile('dist/index.html',html);await writeFile('dist/aonami-fishing.html',html);
console.log('Built self-contained HTML: '+Math.round(Buffer.byteLength(html)/1024)+' KB; Three.js and all assets included.');
